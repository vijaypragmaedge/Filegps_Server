HBase Spark + Kafka Integration. Follow below steps to test the functionality

1. Configure hadoop-2.7.4 and start server.  Follow steps mentioned in this URL - https://hadoop.apache.org/docs/stable/hadoop-project-dist/hadoop-common/SingleCluster.html#Pseudo-Distributed_Operation

2. Download hbase-1.2.6, configure start server.  Follow steps mentioned in this URL - http://hbase.apache.org/book.html#standalone_dist

3. Download Apache Phoenix Hbase compatible version - apache-phoenix-4.10.0-HBase-1.2-bin

    3.1  Download and expand the latest phoenix-[version]-bin.tar.
    3.2  Add the phoenix-[version]-server.jar to the classpath of all HBase region server and master and remove any previous version. An easy way to do this is to copy it into the HBase lib directory (use phoenix-core-[version].jar for Phoenix 3.x)
    3.3  Restart HBase.
    3.4  Add the phoenix-[version]-client.jar to the classpath of any Phoenix client.
For more detail follow - https://phoenix.apache.org/installation.html



        
        
        
4. Create View and indexes
    4.1 CREATE VIEW "ORDER_EVENTS_DATA" ( pk VARCHAR PRIMARY KEY,  "event"."occurred" VARCHAR, "event"."co_relation_id" VARCHAR, "event"."msgTxt" VARCHAR,"event"."nodeId" VARCHAR,"event"."localFileName" VARCHAR, "event"."remoteFileName" VARCHAR, "event"."timestamp" UNSIGNED_LONG, "event"."duration" VARCHAR, "event"."successValue" VARCHAR, "event"."clientId" VARCHAR, "event"."destArch" VARCHAR)
    4.2 CREATE VIEW "UN_ORDER_EVENTS_DATA" ( pk VARCHAR PRIMARY KEY, "event"."status" VARCHAR,  "event"."co_relation_id" VARCHAR, "event"."msgTxt" VARCHAR,"event"."nodeId" VARCHAR,"event"."localFileName" VARCHAR, "event"."remoteFileName" VARCHAR,"event"."timestamp" UNSIGNED_LONG,"event"."duration" VARCHAR, "event"."successValue" VARCHAR, "event"."successPerValue" VARCHAR, "event"."clientId" VARCHAR)
    4.3 CREATE VIEW "SLA_DATA" ( pk VARCHAR PRIMARY KEY, "sla"."success_value_sla" VARCHAR, "sla"."duration_sla" VARCHAR,"sla"."client_id" VARCHAR)

4. Configure and Start spark Master and worker server. Follow steps mentioned in this URL. https://www.dezyre.com/apache-spark-tutorial/spark-tutorial

5. Download Kakfa and Configure Kafka as below.

6. Open config/zookeeper.properties and change zookeeper port if hbase and kafka are running on same machine.

### start zookeeper
if you have installed zookeeper, start it, or
run the command:
``` sh
bin/zookeeper-server-start.sh config/zookeeper.properties
```

### start kafka with default configuration
``` sh
> bin/kafka-server-start.sh config/server.properties
```

### create a topic
``` sh
> bin/kafka-topics.sh --create --zookeeper localhost:2181 --replication-factor 1 --partitions 10 --topic test_topic
```

7. Import Kafka-Consumer projects in intellij Idea and build require jar. Or run maven clean package

### Run the Consumer (go to target folder and run below command from console)
### Program parameters - Param 1 is broker address.  Param 2 is zookeeper address of Hbase.  Param 3 is name of topic
java -cp "kafka_spark_consumer-0.1.0-SNAPSHOT.jar:../lib/*" com.spark.kafka.SparkHBaseClient localhost:9092 localhost:2181 topic unorder oracle

java -cp "kafka_spark_consumer-0.1.0-SNAPSHOT.jar:../lib/*" com.spark.kafka.SparkHBaseUnOrderClient localhost:9092 localhost:2181 unorder oracle

java -cp "kafka_spark_consumer-0.1.0-SNAPSHOT.jar:../lib/*" com.spark.kafka.SparkHBaseOracleClient localhost:9092 localhost:2181 oracle

java -cp "kafka_spark_consumer-0.1.0-SNAPSHOT.jar:../lib/*" com.spark.kafka.SparkHBaseOracleSLAClient localhost:9092 localhost:2181 sla


Run below command on apache pheonix to validate -

0: jdbc:phoenix:localhost>select count(*) from ORDER_EVENTS_DATA;


apache Nifi Processor - Prebuilt 
Produce Kafka

SELECT * FROM ORDER_EVENTS_DATA as e WHERE e."localFileName" = ALL (SELECT "remoteFileName" FROM ORDER_EVENTS_DATA WHERE "remoteFileName" = e."localFileName" ORDER BY e."timestamp" DESC) ;

TOP LEVEL QUERIES
select * fromm Where "timestamp" >= TO_TIMESTAMP('2005-10-01 14:03:22.559') And "timestamp" <= TO_TIMESTAMP('2005-10-01 14:03:22.559')  and "clientId" = ? And ("localFileName"= ?)

Drill Down Query :

select * fromm Where "timestamp" >= TO_TIMESTAMP('2005-10-01 14:03:22.559') And "timestamp" <= TO_TIMESTAMP('2005-10-01 14:03:22.559')  and "clientId" = ? And ("remoteFileName"= ?) and co_relation_id=?

TOP LEVEL :
SELECT * FROM ORDER_EVENTS_DATA as e WHERE   e."timestamp" >= TO_TIMESTAMP('2005-10-01 14:03:22.559') And e."timestamp" <= TO_TIMESTAMP('2005-10-01 14:03:22.559')  and e."clientId" = ?  AND e."localFileName" = ALL (SELECT "remoteFileName" FROM ORDER_EVENTS_DATA WHERE "remoteFileName" = e."localFileName") ORDER BY e."timestamp" DESC;

Drill Down Query :
SELECT * FROM ORDER_EVENTS_DATA as e WHERE   e."timestamp" >= TO_TIMESTAMP('2005-10-01 14:03:22.559') And e."timestamp" <= TO_TIMESTAMP('2005-10-01 14:03:22.559')  and e."clientId" = ? and co_relation_id=? AND e."remoteFileName" = ALL (SELECT "localFileName" FROM ORDER_EVENTS_DATA WHERE "localFileName" = e."remoteFileName") ORDER BY e."timestamp" DESC;


SELECT PatentID, Title
FROM Patents p
JOIN
    (SELECT "remoteFileName" FROM ORDER_EVENTS_DATA WHERE "remoteFileName" = e."localFileName") ORDER BY e."timestamp" DESC) t1
ON Region = t1.col1
WHERE FileDate <= ALL(t1.col2);


SELECT * FROM ORDER_EVENTS_DATA as e1 JOIN (SELECT  e2."co_relation_id", e2."msgTxt" FROM ORDER_EVENTS_DATA as e2 WHERE e2."msgTxt" IN ('Process', 'Stop') GROUP BY e2."co_relation_id",e2."msgTxt" ) AS e3 ON e1."co_relation_id" = e3."co_relation_id";

SELECT  e2."co_relation_id", e2."msgTxt" FROM ORDER_EVENTS_DATA as e2 WHERE e2."co_relation_id" = ALL (SELECT e1.co_relation_id FROM ORDER_EVENTS_DATA as e1 WHERE e.1"co_relation_id" = e2."co_relation_id");