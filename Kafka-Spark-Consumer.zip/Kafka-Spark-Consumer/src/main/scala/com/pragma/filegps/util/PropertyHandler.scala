package com.pragma.filegps.util

import scala.io.Source
import java.util.Properties
import org.apache.log4j.Logger
import org.slf4j.LoggerFactory
import java.io.FileNotFoundException

object PropertyHandler extends Serializable {
  val logger = Logger.getLogger(PropertyHandler.getClass)
  var props: Properties = null;
  def loadProperties() = {
    try {
      if (props == null) {
        props = new Properties()
        val source = Source.fromFile("application.properties").bufferedReader()
        props.load(source)
      }
    } catch {
      case e: FileNotFoundException => logger.error("Error Occured while loading properties file...Reason :" + e.getMessage)
    }
  }

  def getValue(key: String): String = {
    if (props != null) {
      val value = props.getProperty(key)
      logger.info("Key :" + key + ", Value:" + value)
      return value
    }
    return null;
  }

}