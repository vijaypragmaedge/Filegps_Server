package com.pragma.filegps.util

import java.text.SimpleDateFormat
import java.util.{Calendar, Date}

object DateUtil {


  def findStartOfMonth(month:Int, date:Int) : Date = {
    val  cal:Calendar = Calendar.getInstance();
    cal.setTime(new Date())
    cal.add(Calendar.MONTH, month)
    cal.add(Calendar.DATE,date)
    cal.set(Calendar.DAY_OF_MONTH, 1)
    cal.set(Calendar.HOUR_OF_DAY, 0)
    cal.set(Calendar.MINUTE, 0)
    cal.set(Calendar.SECOND, 0)
    cal.set(Calendar.MILLISECOND, 0)


    return cal.getTime;
  }
  def findEndOfMonth(month:Int, date:Int) : Date = {
    val  cal:Calendar = Calendar.getInstance();
    cal.setTime(new Date())
    cal.add(Calendar.MONTH, month)
    cal.add(Calendar.DATE, date)
    cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DATE))

    cal.set(Calendar.HOUR_OF_DAY, cal.getActualMaximum(Calendar.HOUR_OF_DAY))
    cal.set(Calendar.MINUTE,  cal.getActualMaximum(Calendar.MINUTE))
    cal.set(Calendar.SECOND, cal.getActualMaximum(Calendar.SECOND))
    cal.set(Calendar.MILLISECOND, cal.getActualMaximum(Calendar.MILLISECOND))


    return cal.getTime
  }

  def parseDate(date:String, pattern:String) : Date = {
    val formatter = new SimpleDateFormat(pattern)
    return formatter.parse(date)
  }
 
  def parseDate(date:Long, pattern:String) : Date = {
    return new Date(date)
  }
  def formatDate(date:Long, pattern:String) : String = {
    val formatter = new SimpleDateFormat(pattern)
    return formatter.format(new Date(date))
  }

  def print(date:Long) = {
    import java.text.SimpleDateFormat
    val formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S")
    println(" Date "+ formatter.format(new Date(date)));
  }

  def main(args: Array[String]): Unit = {
    findStartOfMonth(1, 1)

    import java.text.SimpleDateFormat
    val formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S")

    println(" Date "+ formatter.format(findStartOfMonth(-12, -1)));
    println(" Date "+ formatter.format(findEndOfMonth(-1, -1)));
    
  }
}
