package com.pragma.filegps.util

import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.Properties
import scala.annotation.tailrec
import org.apache.log4j.Logger
import javax.activation.DataHandler
import javax.activation.FileDataSource
import javax.mail.Message
import javax.mail.PasswordAuthentication
import javax.mail.Session
import javax.mail.Transport
import javax.mail.internet.InternetAddress
import javax.mail.internet.MimeBodyPart
import javax.mail.internet.MimeMessage
import javax.mail.internet.MimeMultipart
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import java.io.File
import org.apache.commons.io.IOUtils
import java.io.ByteArrayOutputStream
import scala.collection.JavaConversions
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream
import collection.JavaConverters._
import sys.process._
import java.util.regex.Pattern
import java.nio.file.Files
import java.nio.file.Paths
import javax.mail.util.ByteArrayDataSource


object EmailUtil {
  PropertyHandler.loadProperties()
  val logger = Logger.getLogger(EmailUtil.getClass)
  val emailProps = new Properties();
  var smtpHost = PropertyHandler.getValue("email.smtp.server")
  var smtpPort = PropertyHandler.getValue("email.smtp.port")
  var emailUserName = PropertyHandler.getValue("email.userName")
  var emailPassword = PropertyHandler.getValue("email.password")
  var emailSubject = PropertyHandler.getValue("email.subject")
  var emailFrom = PropertyHandler.getValue("email.from")
  var emailBcc = PropertyHandler.getValue("email.bcc")
  case class Mail(
    from: String,
    to: Seq[String],
    cc: Seq[String] = Seq.empty,
    bcc: Seq[String] = Seq.empty,
    subject: String,
    message: String,
    attachment: Option[(java.io.File)] = None)
  def getMailProperties(): Properties = {
    if (emailProps.isEmpty()) {
      emailProps.put("mail.smtp.host", smtpHost);
      emailProps.put("mail.smtp.socketFactory.port", smtpPort);
      //emailProps.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
      emailProps.put("mail.smtp.auth", "true");
      emailProps.put("mail.smtp.port", smtpPort);
      emailProps.put("mail.smtp.socketFactory.fallback", "false");
      emailProps.put("mail.smtp.starttls.enable", "true");
      emailProps.put("mail.smtp.ssl.enable", "false");
      emailProps.put("mail.transport.protocol", "smtp");

    }
    return emailProps;
  }

  def getMailSession(): Session = {
    val mailSession = Session.getDefaultInstance(getMailProperties(), new javax.mail.Authenticator() {
      protected override def getPasswordAuthentication(): PasswordAuthentication = {
        return new PasswordAuthentication(emailUserName, emailPassword);
      }
    });
    return mailSession;
  }

  def sendMail(mail: Mail) {


    val message = new MimeMessage(getMailSession());
    message.setFrom(new InternetAddress(emailFrom));
    message.setSubject(mail.subject);
    message.addRecipient(Message.RecipientType.BCC, new InternetAddress(
      emailBcc));
    message.setRecipient(Message.RecipientType.TO, new InternetAddress(mail.to.mkString(",")));
    val multipart = new MimeMultipart("related");
    var messageBodyPart = new MimeBodyPart();
    var imageContent = mail.message
    messageBodyPart.setContent(mail.message, "text/html");
    multipart.addBodyPart(messageBodyPart);
    try {

      var str = imageContent
      //logger.info("Given image value..."+str)
      val imageIds = getImages(mail.message)

      imageIds.foreach { x =>
        messageBodyPart = new MimeBodyPart();
        messageBodyPart.setDisposition("INLINE")
        messageBodyPart.setHeader("Content-ID", "<" + x + ">");
        try {
          messageBodyPart.attachFile(PropertyHandler.getValue("images.folder") + x);
        } catch {
          case e: Exception => logger.error("Error occured in attaching image file to email.." + e.getMessage)
        }
        multipart.addBodyPart(messageBodyPart);
      }
      message.setContent(multipart);
      logger.info("Sending mail....")
      Transport.send(message);
      logger.info("Done....")
    } catch {
      case e: Exception => e.printStackTrace()
    }
  }

  /**
   * get ImageIds for current email template
   */
  def getImages(mailMessage: String): Seq[String] = {

    var message = mailMessage;
    var imageIds: Seq[String] = Seq()
    while (message.contains("src=\"cid")) {
      var ptr = "src\\s*=\\s*([\"'])?([^\"']*)"
      var p = Pattern.compile(ptr);
      var m = p.matcher(message);
      var subMessage = "";
      if (m.find()) {
        subMessage = m.group() //Result
        logger.info("Image Tag Id..." + subMessage)
      }

      message = message.replace(subMessage, "")
      subMessage = subMessage.substring(subMessage.indexOf("cid:") + 4)
      logger.info("Image Id.." + subMessage)
      imageIds = imageIds :+ subMessage

    }
    imageIds;
  }


  
}