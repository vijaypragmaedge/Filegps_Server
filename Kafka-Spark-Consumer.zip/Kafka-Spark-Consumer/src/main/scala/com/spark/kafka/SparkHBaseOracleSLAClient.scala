package com.spark.kafka

import java.util

import kafka.serializer.StringDecoder
import org.apache.hadoop.hbase.{HBaseConfiguration, TableName}
import org.apache.hadoop.hbase.client._
import org.apache.hadoop.hbase.filter.CompareFilter.CompareOp
import org.apache.hadoop.hbase.filter.{Filter, FilterList, SingleColumnValueFilter}
import org.apache.hadoop.hbase.util.Bytes
import org.apache.kafka.clients.producer.{KafkaProducer, ProducerConfig, ProducerRecord}
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.apache.spark.streaming.kafka.KafkaUtils
import com.pragma.filegps.util.DateUtil
import scala.collection.mutable.ListBuffer
import scala.concurrent.duration.Duration

object SparkHBaseOracleSLAClient {
  case class Calculation(count:Long, duration:Long, sv:Long)

  def main(args: Array[String]) = {
    //var url:String = "jdbc:oracle:thin:@pcmdemo.careuhhgvzsm.us-east-1.rds.amazonaws.com:1521:ORCL"
    var url:String = "org.apache.phoenix.jdbc.PhoenixDriver"
    val clientInfoJdbc:PhoenixJdbcClient  = new PhoenixJdbcClient(url, "FILEGPS", "QbHMTP7V")
   // clientInfoJdbc.getConnection();
    val kafkaBroker = args(0) //"localhost:9092"
    val zk = args(1)  
    val topic = args(2)

    val conf = new SparkConf()
      .setAppName("SparkHBaseStream")
      .setMaster("local[4]")

    val sc = new SparkContext(conf)
    val ssc = new StreamingContext(sc, Seconds(5))
    val topics = Array(topic).toSet;
    val kafkaParams = Map[String, String]("metadata.broker.list" -> kafkaBroker, "group.id" -> "group1");
    var kafkaStream = KafkaUtils.createDirectStream[String, String, StringDecoder, StringDecoder](ssc, kafkaParams, topics)
    var inputStream = kafkaStream.map(_._2);
    inputStream = inputStream.repartition(12);

    inputStream.foreachRDD(rdd => if (!rdd.isEmpty())  rdd.foreach(row => {
      println("******************************************")
      println("Received mesasge " + row)
      durationAverage(zk, clientInfoJdbc)
      println("********************Processed**********************")

    }))
    ssc.start()
    ssc.awaitTermination()

  }

  def durationAverage(zk:String, jdbc:PhoenixJdbcClient) {
    val hConf = HBaseConfiguration.create()
    hConf.set("hbase.zookeeper.quorum", zk)
    val tableName = "ORDER_EVENTS_DATA"
    val hTable = new HTable(hConf, tableName)
    println("******************Fetching client..************************")
    val slaPeriods:ListBuffer[SLAPeriod]= jdbc.findSLAPeriod();
    println("******************Fetched************************")
    println("Client data " + slaPeriods);
    slaPeriods.foreach(p=>{
      println(" SLA  "+ p)
      if(p!=null) {
       println(" SLA data "+ p.clientIdRef)

      val scan: Scan = new Scan();

      val filterAggregate:FilterList = new FilterList(FilterList.Operator.MUST_PASS_ALL)

      val successValueFilterList: FilterList = new FilterList(FilterList.Operator.MUST_PASS_ONE)
      var f1: SingleColumnValueFilter = new SingleColumnValueFilter(Bytes.toBytes("event"), Bytes.toBytes("successValue"), CompareOp.EQUAL, Bytes.toBytes(100+""))
      f1.setFilterIfMissing(true)
      successValueFilterList.addFilter(f1);

      f1 = new SingleColumnValueFilter(Bytes.toBytes("event"), Bytes.toBytes("successValue"), CompareOp.EQUAL, Bytes.toBytes(0+""))
      f1.setFilterIfMissing(true)
      successValueFilterList.addFilter(f1);

     // println( "p.clientIdRef "+ p.clientIdRef)
      val clientNameAndDateRange: FilterList = new FilterList(FilterList.Operator.MUST_PASS_ALL)
      f1 = new SingleColumnValueFilter(Bytes.toBytes("event"), Bytes.toBytes("clientId"), CompareOp.EQUAL, Bytes.toBytes(p.clientIdRef))
      f1.setFilterIfMissing(true)
      clientNameAndDateRange.addFilter(f1);


        println( "********************** from timeRefFrom *****************")
        println( "********************** :"+DateUtil.formatDate(p.timeRefFrom, "yyyy-MM-dd HH:mm:ss.S")+":  *****************")
      f1 = new SingleColumnValueFilter(Bytes.toBytes("event"), Bytes.toBytes("timestamp"), CompareOp.GREATER_OR_EQUAL, Bytes.toBytes(p.timeRefFrom))
      f1.setFilterIfMissing(true)
      clientNameAndDateRange.addFilter(f1);

        println( "********************** from timeRefTo *****************")
        println( "********************** :"+DateUtil.formatDate(p.timeRefTo, "yyyy-MM-dd HH:mm:ss.S")+":  *****************")
      f1 = new SingleColumnValueFilter(Bytes.toBytes("event"), Bytes.toBytes("timestamp"), CompareOp.LESS_OR_EQUAL, Bytes.toBytes(p.timeRefTo))
      f1.setFilterIfMissing(true)
      clientNameAndDateRange.addFilter(f1);

        filterAggregate.addFilter(clientNameAndDateRange)
      filterAggregate.addFilter(successValueFilterList)
      //scan.setFilter(successValueFilterList);

      scan.setFilter(filterAggregate)

      val result :ResultScanner= hTable.getScanner(scan);
      val iter = result.iterator();

      val e:Event = new Event()
      var count:Int = 0

      var group:Map[String, Calculation] =  Map()
        println( "********************** Finding Hbase *****************")
      while(iter.hasNext) {
        val r:Result = iter.next()
        println( "Found Match Data from HBase "+Bytes.toString(r.getValue(e.cfDataBytes, e.successValue)))

        val sv:Int =  Bytes.toString(r.getValue(e.cfDataBytes, e.successValue)).toInt;
        var d:Long = 0;
        if(r.getValue(e.cfDataBytes, e.duration)!=null) {
          d =  Bytes.toString(r.getValue(e.cfDataBytes, e.duration)).toLong;

        }
         val cid:String =  Bytes.toString(r.getValue(e.cfDataBytes, e.clientIdBytes));
        println("cid"+ cid)
        if (group.contains(cid)){
          println("contain cid"+ cid)
          //  var c:Int =group.get(cid).get;
          var cal : Calculation = group.get(cid).get;
          cal = new Calculation(cal.count+1, cal.duration+d, sv+cal.sv)
          group=  group.+(cid-> cal)
          println( "********************** Count *****************")
          println( "********************** "+cal.count+" *****************")
        } else {
          println("not contain cid"+ cid)
          val cal:Calculation = new Calculation(1, d, sv)
          group=  group.+(cid-> cal)
        }
        count = count+1;
      }

      println(group)

      updateSLA(group, zk, p, jdbc)
      //TODO: update oracle table
      //TODO: alert table
      }
    })




  }


  def updateSLA(slaMap:Map[String, Calculation], zk:String, sla:SLAPeriod, jdbc:PhoenixJdbcClient) {



    val hConf =  HBaseConfiguration.create()
    hConf.set("hbase.zookeeper.quorum", zk)
    val tableName = "SLA_DATA"
    val admin = new HBaseAdmin(hConf)
    if (!admin.isTableAvailable(tableName)) {
      import org.apache.hadoop.hbase.{HColumnDescriptor, HTableDescriptor}
      var family = new HColumnDescriptor(Bytes.toBytes("sla"))
      var tableDesc = new HTableDescriptor(TableName.valueOf(tableName))
      tableDesc.addFamily(family);
      admin.createTable(tableDesc)

    }
    val hTable = new HTable(hConf, tableName)

    slaMap.foreach(m => {
      val clientId:String =m._1
      val cal:Calculation = m._2;
   //   println(" cal.sv  " + cal.sv)
      val SLAavg :Double = cal.sv/cal.count;
   //   println(" cal.sv  SLAavg " + SLAavg)
    //  println("SLAavg" +SLAavg)


      val durartionSLAavg :Double = cal.duration/cal.count;
      val rowKey:String = clientId+"_"+System.currentTimeMillis();
      var put:Put = new Put(Bytes.toBytes(rowKey));
      put.addColumn(Bytes.toBytes("sla"), Bytes.toBytes("success_value_sla"), Bytes.toBytes(SLAavg+""))
      put.addColumn(Bytes.toBytes("sla"), Bytes.toBytes("duration_sla"), Bytes.toBytes(durartionSLAavg+""))
      put.addColumn(Bytes.toBytes("sla"), Bytes.toBytes("client_id"), Bytes.toBytes(clientId))
      hTable.put(put)
      hTable.flushCommits();
      if(sla.slaType!=null && sla.slaType.equalsIgnoreCase("D")){
        jdbc.updateClientSLA(durartionSLAavg, sla);
      } else
        jdbc.updateClientSLA(SLAavg, sla);
    })
//N(ns3(34FqlO
    println("Saved.")

  }

}
