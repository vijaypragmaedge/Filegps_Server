package com.spark.kafka

import java.util

import kafka.serializer.StringDecoder
import org.apache.hadoop.hbase.client._
import org.apache.hadoop.hbase.filter.CompareFilter.CompareOp
import org.apache.hadoop.hbase.filter.{FilterList, SingleColumnValueFilter}
import org.apache.hadoop.hbase.util.Bytes
import org.apache.hadoop.hbase.{HBaseConfiguration, TableName}
import org.apache.kafka.clients.producer.{KafkaProducer, ProducerConfig, ProducerRecord}
import org.apache.spark.streaming.kafka.KafkaUtils
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.apache.spark.{SparkConf, SparkContext}

class SparkHBaseUnOrderClient {

}

object SparkHBaseUnOrderClient {

  def main(args: Array[String]) = {
    val kafkaBroker = args(0) //"localhost:9092"
    val zk = args(1)
    val topic = args(2)
    val oracleDurationCalculationTopic = args(3)
    val conf = new SparkConf()
      .setAppName("SparkHBaseStream")
      .setMaster("local[4]")

    val sc = new SparkContext(conf)
    val ssc = new StreamingContext(sc, Seconds(5))
    val topics = Array(topic).toSet;
    val kafkaParams = Map[String, String]("metadata.broker.list" -> kafkaBroker, "group.id" -> "group1");
    var kafkaStream = KafkaUtils.createDirectStream[String, String, StringDecoder, StringDecoder](ssc, kafkaParams, topics)
    var inputStream = kafkaStream.map(_._2);
    inputStream = inputStream.repartition(12);
    /*val parsedStream = inputStream.mapPartitions {
      rows =>
        rows.map { row =>

        }
    }*/
    inputStream.foreachRDD(rdd => if (!rdd.isEmpty()) rdd.foreach(row => linkUnOrderData(zk, kafkaBroker, topic, oracleDurationCalculationTopic)))
    ssc.start()
    ssc.awaitTermination()

  }

  def linkUnOrderData(zk:String, kafkaBroker:String, topic:String, oracleDurationCalculationTopic:String) {
    val hConf = HBaseConfiguration.create()
    hConf.set("hbase.zookeeper.quorum", zk)
    val tableName = "ORDER_EVENTS_DATA"
    val unOrderedEvent = "UN_ORDER_EVENTS_DATA"
    // Initialize hBase table if necessary

    val hTable = new HTable(hConf, tableName)
    val unOrderedEventTable = new HTable(hConf, unOrderedEvent)
    val scan: Scan = new Scan();
    val allFilters: FilterList = new FilterList(FilterList.Operator.MUST_PASS_ALL)
    val f1: SingleColumnValueFilter = new SingleColumnValueFilter(Bytes.toBytes("event"), Bytes.toBytes("co_relation_id"), CompareOp.EQUAL, Bytes.toBytes("EMPTY"))
    allFilters.addFilter(f1);
    scan.setFilter(allFilters);
    val result :ResultScanner= unOrderedEventTable.getScanner(scan);
    val iter = result.iterator();
    val e:Event = new Event();
    var unorderRows:Int = 0;
    while(iter.hasNext){
      var coRelationId: String = null;
      var sub_co_relation_id:String = null;
      val r:Result  = iter.next()
      val msgTxt  : String = Bytes.toString(r.getValue(e.cfDataBytes, e.msgTxtBytes));
      val nodes :Array[String] = Bytes.toString(r.getValue(e.cfDataBytes, e.nodeIdBytes)).split("/")
      val r1:String = nodes(0)
      val r2:String = Bytes.toString(r.getValue(e.cfDataBytes, e.localFileNameBytes))
      val rowKey:String = r1 + "_"+r2;
      println(" ROW ID + " + rowKey)
      var get:Get = new Get(Bytes.toBytes(rowKey))
      get = get.addFamily(Bytes.toBytes("event"))
      var found:Result = hTable.get(get)
      if(found.isEmpty) {

      }
      coRelationId = Bytes.toString(found.getValue(e.cfDataBytes, e.corelationId))
      
      sub_co_relation_id= Bytes.toString(found.getValue(e.cfDataBytes, Bytes.toBytes("sub_co_relation_id")))
      println(" coRelationId ID found " + coRelationId)
      val command  : String = Bytes.toString(found.getValue(e.cfDataBytes, e.msgTxtBytes));

      if(!found.isEmpty && (coRelationId!=null && !coRelationId.equalsIgnoreCase("EMPTY"))){
        println( "row" +nodes(1) + "_" + Bytes.toString(found.getValue(e.cfDataBytes, e.remoteFileNameBytes)))
        println("********* command "+msgTxt + " *************")
        val put : Put = new  Put(r.getRow)
       // found.getFamilyMap(Bytes.toBytes("event"))direction
      // val put = new Put(Bytes.toBytes(nodes(1) + "_" + Bytes.toString(found.getValue(e.cfDataBytes, e.remoteFileNameBytes))))
        put.add(e.cfDataBytes, e.directionBytes, r.getValue(e.cfDataBytes, e.directionBytes))
        put.add(e.cfDataBytes, e.eventBytes, r.getValue(e.cfDataBytes, e.eventBytes))
        put.add(e.cfDataBytes, e.msgIdBytes, r.getValue(e.cfDataBytes, e.msgIdBytes))
        put.add(e.cfDataBytes, e.msgTxtBytes,r.getValue(e.cfDataBytes, e.msgTxtBytes))
        put.add(e.cfDataBytes, e.msgCodeBytes, r.getValue(e.cfDataBytes, e.msgCodeBytes))
        put.add(e.cfDataBytes, e.nodeIdBytes, r.getValue(e.cfDataBytes, e.nodeIdBytes))
        put.add(e.cfDataBytes, e.occurredBytes, r.getValue(e.cfDataBytes, e.occurredBytes))
        put.add(e.cfDataBytes, e.processIdBytes, r.getValue(e.cfDataBytes, e.processIdBytes))
        put.add(e.cfDataBytes, e.processNameBytes, r.getValue(e.cfDataBytes, e.processNameBytes))
        put.add(e.cfDataBytes, e.stepNameBytes, r.getValue(e.cfDataBytes, e.stepNameBytes))
        put.add(e.cfDataBytes, e.localFileNameBytes, r.getValue(e.cfDataBytes, e.localFileNameBytes))
        put.add(e.cfDataBytes, e.localPathBytes, r.getValue(e.cfDataBytes, e.localPathBytes))
        put.add(e.cfDataBytes, e.remoteFileNameBytes, r.getValue(e.cfDataBytes, e.remoteFileNameBytes))
        put.add(e.cfDataBytes, e.sentFromBytes, r.getValue(e.cfDataBytes, e.sentFromBytes))
        put.add(e.cfDataBytes, e.sentToBytes,r.getValue(e.cfDataBytes, e.sentToBytes))
        put.add(e.cfDataBytes, e.clientNameBytes, r.getValue(e.cfDataBytes, e.clientNameBytes))
        put.add(e.cfDataBytes, e.timeStampBytes, r.getValue(e.cfDataBytes, e.timeStampBytes))
        put.add(e.cfDataBytes, e.clientIdBytes, r.getValue(e.cfDataBytes, e.clientIdBytes))
        put.add(e.cfDataBytes, e.corelationId, Bytes.toBytes(coRelationId))
         if(sub_co_relation_id !=null){
        println("sub_co_relation_id -inside if")
        put.addColumn(e.cfDataBytes, Bytes.toBytes("sub_co_relation_id"),Bytes.toBytes(sub_co_relation_id))
         }
       // if(msgTxt!=null && !msgTxt.equalsIgnoreCase("stop")) {
          val timeStart: Long = Bytes.toLong(found.getValue(e.cfDataBytes, e.timeStampBytes));
          val diff: Long = Bytes.toLong(r.getValue(e.cfDataBytes, e.timeStampBytes)) - timeStart;
          val duration: Long = (diff / (1000 * 60 * 60)) % 24
          put.addColumn(e.cfDataBytes, e.duration, Bytes.toBytes(diff + ""))

       // }
        put.addColumn(e.cfDataBytes, e.successValue, Bytes.toBytes(100 + ""))
        println(" coRelationId ID + " + coRelationId)
        println(" sub_co_relation_id ID + " + sub_co_relation_id)
        println("Saved.")
        hTable.put(put)
        hTable.flushCommits();
        //deletes.add(new Delete(found.getRow))
        unOrderedEventTable.delete(new Delete(r.getRow))
        unOrderedEventTable.flushCommits();
        //if stop and post message to oracle durration consumer

        if(msgTxt!=null && msgTxt.equalsIgnoreCase("stop")){
          try {
            val props = new util.HashMap[String, Object]()
            props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaBroker)
            props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,
              "org.apache.kafka.common.serialization.StringSerializer")
            props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,
              "org.apache.kafka.common.serialization.StringSerializer")
            val producer = new KafkaProducer[String, String](props)
            println(" *********** Sending message to oracle topic : under order *************************")
            val message = new ProducerRecord[String, String](oracleDurationCalculationTopic, "192.168.1.9", Bytes.toString(r.getRow))
            producer.send(message)
            println(" *********** Sending message to oracle topic  from under order: sent *************************")
          } catch   {
            case e:Exception => {
              println(e)
            }
          }
        }
        //

      } else {
        unorderRows = unorderRows+1;
      }
      //  val puts:util.List[Put] = new util.ArrayList[Put]()
     /* if(msgTxt!=null && !msgTxt.equalsIgnoreCase("stop")) {

             hTable.put(puts)
          hTable.flushCommits();
          deletes.add(new Delete(found.getRow))
          unOrderedEventTable.delete(deletes)
          unOrderedEventTable.flushCommits();
      /*val e:Event = new Event();
      var get:Get = new Get(r.getRow)
      get = get.addFamily(Bytes.toBytes("event"))
      val found:Result = hTable.get(get)
      val puts:util.List[Put] = new util.ArrayList[Put]()
      puts.add(new Put(get.getRow))
      val msgTxt  : String = Bytes.toString(found.getValue(e.e.cfDataBytes, e.msgTxtBytes));
      var coRelation: String = null;
      if(msgTxt!=null && !msgTxt.equalsIgnoreCase("stop")) {
        coRelation = findStartOfEvent(found, puts, unOrderedEventTable);
        if(coRelation!=null) {
          val it:util.Iterator[Put] = puts.iterator()
          val deletes:util.List[Delete] = new util.ArrayList[Delete]()
          while(it.hasNext) {
            val p : Put = it.next();
            p.add(e.e.cfDataBytes, e.corelationId, Bytes.toBytes(coRelation))
            deletes.add(new Delete(p.getRow))
          }     //coRelation = findStopOfEvent(hTable.get(get), puts, hTable)

          hTable.put(puts)
          hTable.flushCommits();
          deletes.add(new Delete(found.getRow))
          unOrderedEventTable.delete(deletes)
          unOrderedEventTable.flushCommits();
        }*/
      } else {
        //TODO: handle stop event

        coRelation = findStopOfEvent(found, puts, hTable, false);
        if(coRelation!=null) {
          val deletes:util.List[Delete] = new util.ArrayList[Delete]()
          val it:util.Iterator[Put] = puts.iterator()
          while(it.hasNext) {
            val p : Put = it.next();
            p.add(e.e.cfDataBytes, e.corelationId, Bytes.toBytes(coRelation))
            deletes.add(new Delete(p.getRow))
          }     //coRelation = findStopOfEvent(hTable.get(get), puts, hTable)


          hTable.put(puts)
          hTable.flushCommits();

          deletes.add(new Delete(found.getRow))
          unOrderedEventTable.delete(deletes)
        }

      }*/

    }
    if(unorderRows>0){
      val props = new util.HashMap[String, Object]()
      props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaBroker)
      props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,
        "org.apache.kafka.common.serialization.StringSerializer")
      props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,
        "org.apache.kafka.common.serialization.StringSerializer")

      val producer = new KafkaProducer[String, String](props)

      try {
        val message = new ProducerRecord[String, String](topic, "192.168.1.10", "unorder data")
        producer.send(message)
      } catch   {
        case e:Exception => {
          println(e)
        }
      }
    }

  }




}