package com.spark.kafka

import java.util
import java.util.concurrent.TimeUnit

import kafka.serializer.StringDecoder
import org.apache.hadoop.hbase.{HBaseConfiguration, TableName}
import org.apache.hadoop.hbase.client._
import org.apache.hadoop.hbase.filter.CompareFilter.CompareOp
import org.apache.hadoop.hbase.filter.{FilterList, SingleColumnValueFilter}
import org.apache.hadoop.hbase.util.Bytes
import org.apache.kafka.clients.producer.{KafkaProducer, ProducerConfig, ProducerRecord}
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.apache.spark.streaming.kafka.KafkaUtils

class SparkHBaseOracleClient {

}

object SparkHBaseOracleClient {

  def main(args: Array[String]) = {
    var url:String = "jdbc:oracle:thin:@pcmdemo.careuhhgvzsm.us-east-1.rds.amazonaws.com:1521:ORCL"
   // val clientInfoJdbc:PhoenixJdbcClient  = new PhoenixJdbcClient(url, "FILEGPS", "QbHMTP7V")
    val clientInfoJdbc:PhoenixJdbcClient  = new PhoenixJdbcClient(url,"FILEGPS","QbHMTP7V")
    val kafkaBroker = args(0) //"localhost:9092"
    val zk = args(1)
    val topic = args(2)

    val conf = new SparkConf()
      .setAppName("SparkHBaseStream")
      .setMaster("local[4]")

    val sc = new SparkContext(conf)
    val ssc = new StreamingContext(sc, Seconds(5))
    val topics = Array(topic).toSet;
    val kafkaParams = Map[String, String]("metadata.broker.list" -> kafkaBroker, "group.id" -> "group1");
    var kafkaStream = KafkaUtils.createDirectStream[String, String, StringDecoder, StringDecoder](ssc, kafkaParams, topics)
    var inputStream = kafkaStream.map(_._2);
   // inputStream = inputStream.repartition(12);

    inputStream.foreachRDD(rdd => if (!rdd.isEmpty())  rdd.foreach(row => findClientInfo(zk,row, clientInfoJdbc, kafkaBroker)))
    ssc.start()
    ssc.awaitTermination()

  }

  def findClientInfo(zk:String, row:String, jdbc:PhoenixJdbcClient, kafkaBroker:String) {
    val hConf = HBaseConfiguration.create()
    hConf.set("hbase.zookeeper.quorum", zk)
    val tableName = "ORDER_EVENTS_DATA"
    val hTable = new HTable(hConf, tableName)
    val props = new util.HashMap[String, Object]()
    props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaBroker)
    props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,
      "org.apache.kafka.common.serialization.StringSerializer")
    props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,
      "org.apache.kafka.common.serialization.StringSerializer")

    val producer = new KafkaProducer[String, String](props)

    val e:Event = new Event();
    println("Stop row Id "+ row);
    var stopEvent:Get = new Get(Bytes.toBytes(row))
    stopEvent = stopEvent.addFamily(Bytes.toBytes("event"))
    val stopRow:Result = hTable.get(stopEvent)
    val msgTxt  : String = Bytes.toString(stopRow.getValue(e.cfDataBytes, e.msgTxtBytes));
    if(msgTxt!=null && msgTxt.equalsIgnoreCase("stop")) {
      val startRowBytes:Array[Byte] = findSartOfEvent(stopRow,  hTable, false);
      println("Stop row Id "+ Bytes.toString(startRowBytes));
      var startEvent:Get = new Get(startRowBytes)
      startEvent = startEvent.addFamily(Bytes.toBytes("event"))
      val startRow:Result = hTable.get(startEvent)
      var clientId:String = Bytes.toString(startRow.getValue(e.cfDataBytes, e.clientIdBytes));
      val sub_co_relation_id =  Bytes.toString(startRow.getValue(e.cfDataBytes, Bytes.toBytes("sub_co_relation_id")))
      println(" clientId from start "+ clientId)
      if(clientId==null){
        clientId = Bytes.toString(stopRow.getValue(e.cfDataBytes, e.clientIdBytes));
        println(" clientId from stop "+ clientId)
      }

      val timeStampStop:Long   = Bytes.toLong(stopRow.getValue(e.cfDataBytes, e.timeStampBytes));
      val timeStampStart:Long   = Bytes.toLong(startRow.getValue(e.cfDataBytes, e.timeStampBytes));
      val diff : Long = timeStampStop - timeStampStart;
      println(" Time stamp diff  " + diff)
      val duration : Long = (diff/(1000*60*60))%24
      val put:Put = new Put(startRowBytes);
      put.addColumn(e.cfDataBytes, e.duration, Bytes.toBytes(diff+""))
      println("******** : duration :**********")
      println("******** : "+duration+" :**********")
      
     println("sub_co_relation_id- sparkhbaseoraleclient"+sub_co_relation_id)
     if(sub_co_relation_id !=null){
        println("sub_co_relation_id -inside if")
        put.addColumn(e.cfDataBytes, Bytes.toBytes("sub_co_relation_id"),Bytes.toBytes(sub_co_relation_id))
      //  hTable.put(put) 
      }
      if(duration>=1){
        put.addColumn(e.cfDataBytes, e.successValue, Bytes.toBytes(0+""))
        if(sub_co_relation_id !=null){
        println("sub_co_relation_id -inside if")
        put.addColumn(e.cfDataBytes, Bytes.toBytes("sub_co_relation_id"),Bytes.toBytes(sub_co_relation_id))
      //  hTable.put(put) 
      }
      } else {
        put.addColumn(e.cfDataBytes, e.successValue, Bytes.toBytes(100+""))
        if(sub_co_relation_id !=null){
        println("sub_co_relation_id -inside ifesle-100")
        put.addColumn(e.cfDataBytes, Bytes.toBytes("sub_co_relation_id"),Bytes.toBytes(sub_co_relation_id))
      //  hTable.put(put) 
      }
      }

      println("******************")

      /*val clientInfo:ClientInfo = jdbc.findClientInfo(clientId)
      if(clientInfo!=null){
        put.addColumn(e.cfDataBytes, e.successPerValueBytes, Bytes.toBytes(0))
      }*/
      hTable.put(put)
      hTable.flushCommits();
      println("Saved.")

      try {
        println(" *********** Sending message to oracle topic *************************")
        val message = new ProducerRecord[String, String]("SLA", "192.168.1.15", Bytes.toString(put.getRow))
        producer.send(message)
        println(" *********** Sending message to oracle topic : sent *************************")
      } catch   {
        case e:Exception => {
          println(e)
        }
      }
    }

  }

  def findSartOfEvent(r:Result, hTable:HTable, include:Boolean) :Array[Byte] = {
    var row:Array[Byte] = null;
    val e:Event = new Event();
    if(r!=null && Bytes.toString(r.getValue(e.cfDataBytes, e.nodeIdBytes))!=null) {
      val nodes :Array[String] = Bytes.toString(r.getValue(e.cfDataBytes, e.nodeIdBytes)).split("/")
      var r1:String = nodes(1)
      if(include)
        r1= nodes(0)
      val r2:String = Bytes.toString(r.getValue(e.cfDataBytes, e.localFileNameBytes))
      val rowKey:String = r1 + "_"+r2;
      println(" rowKey "+ rowKey);
      var get:Get = new Get(Bytes.toBytes(rowKey))
      get = get.addFamily(Bytes.toBytes("event"))
      val found:Result = hTable.get(get)
      row = found.getRow
      val msgTxt  : String = Bytes.toString(found.getValue(e.cfDataBytes, e.msgTxtBytes));
      println(" msgTxt " + msgTxt)
      if(msgTxt!=null && !msgTxt.equalsIgnoreCase("start")){
        row = findSartOfEvent(found, hTable, true);
      }else {
         return row;
      }
    }
    return row;

  }
}
