package com.spark.kafka

import java.sql.{ Connection, _ }
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import com.pragma.filegps.util.EmailUtil
import com.pragma.filegps.util.DateUtil
import scala.collection.mutable.{ ArrayBuffer, ListBuffer }
import org.apache.spark.sql.SQLContext
import org.apache.phoenix.spark._
import org.apache.spark.{SparkConf, SparkContext}
case class ClientInfo (name:String, clientId:String, successValue:String) extends Serializable
case class SLAPeriod (pk:String, slaType:String,  clientIdRef:String, clientName:String,  slaTimeRef:String, timeRefFrom:Long,
                      timeRefTo:Long, fileTypeRef:String, slaTimePeriod:String, redAlert:Red, greenAlert:Green, yellowAlert:Yellow, slaOldValue:String, slaName:String, description:String) extends Serializable
case class Red(enable:Boolean, startRange:Double, endRange:Double) extends Serializable
case class Yellow(enable:Boolean, startRange:Double, endRange:Double) extends Serializable
case class Green(enable:Boolean, startRange:Double, endRange:Double) extends Serializable
case class Alert(pk:String, name:String, value:Double, clientId:String, clientName:String) extends Serializable
case class AlertInfo( alertName:String , condition:String,description:String, priority:String,period:String, notificationFreqency:String, notificationStartDt:Date ) extends Serializable
case class Subscription_Alert(Subscription_ID:String, Client_ID:String, Client_Name:String,Event_Type:String,File_Type:String, FIl_name_pattern:String,Email_Address:String) extends Serializable

class PhoenixJdbcClient(url: String, user: String, pass: String) extends Serializable {

  var psmt: PreparedStatement = null;
  var updatePsmt: PreparedStatement = null;
  var alertInsert: PreparedStatement = null;
  var alertInfo: PreparedStatement = null;
  var subscriptionInfo: PreparedStatement = null;
   var jsonSchemaverify: PreparedStatement = null;
/*  
  val sc = new SparkContext("local", "phoenix-test")
  val sqlContext = new SQLContext(sc)
  val df = sqlContext.load(
  "org.apache.phoenix.spark",
  Map("table" -> "DUMMY", "zkUrl" -> "localhost:2181")
)*/

  def PhoenixJdbcClient(url: String) = {
    Class.forName("org.apache.phoenix.jdbc.PhoenixDriver");
    //  this.url = url;

  }

  def getConnection(): Connection = {
    return DriverManager.getConnection("jdbc:phoenix:localhost")
  }

  def findSLAPeriod(): ListBuffer[SLAPeriod] = {
    var connection: Connection = getConnection();
    // if(psmt==null){
    psmt = connection.prepareStatement("SELECT  ROWKEY, CLIENT_ID, SLA_TIME_REF, TIME_REF_FROM, TIME_REF_TO, FILE_TYPE, TIME_REF_PERIOD, " +
      "IS_GRE_ZONE, IS_RED_ZONE, IS_YEL_ZONE,  RED_START_RANGE_VALUE, RED_END_RANGE_VALUE,  " +
      "YEL_START_RANGE_VALUE, YEL_END_RANGE_VALUE,  GRE_START_RANGE_VALUE, GRE_END_RANGE_VALUE, CLIENT_NAME, TYPE_OF_SLA, SLA_VALUE, SLA_NAME, DESCRIPTION FROM FILEGPS.PETPE_SLA")
    // }
    var clientInfo: ClientInfo = null;
    val resultSet: ResultSet = psmt.executeQuery()
    var data: ListBuffer[SLAPeriod] = new ListBuffer[SLAPeriod]()
    while (resultSet.next()) {
      val pk: String = resultSet.getString(1)
      val clientIdRef: String = resultSet.getString(2)
      val clientNameRef: String = resultSet.getString("CLIENT_NAME")
      val slaTimeRef: String = resultSet.getString(3)
      val timeRefFrom: String = resultSet.getString(4)
      val timeRefTo: String = resultSet.getString(5)
      val fileTypeRef: String = resultSet.getString(6)
      val timePeriod: String = resultSet.getString(7)
      val slaType: String = resultSet.getString("TYPE_OF_SLA")
      val slaOldValue: String = resultSet.getString("SLA_VALUE")

      var IsZone: String = resultSet.getString("IS_YEL_ZONE")
      var s: String = resultSet.getString("YEL_START_RANGE_VALUE")
      var e: String = resultSet.getString("YEL_END_RANGE_VALUE")
      var slaName: String = resultSet.getString("SLA_NAME")
      var description: String = resultSet.getString("DESCRIPTION")

      var startRange: Double = 0;
      var endRange: Double = 0;
      if (s != null) {
        startRange = s.toDouble;

      }
      if (e != null) {
        endRange = e.toDouble
      }

      var isEnable: Boolean = false;
      if (IsZone != null && IsZone.equalsIgnoreCase("Y")) {
        isEnable = true
      }
      println("IS_YEL_ZONE ZONE " + isEnable);
      println("IS_YEL_ZONE ZONE " + IsZone);
      val yellowAlert: Yellow = Yellow(isEnable, startRange, endRange)

      IsZone = resultSet.getString("IS_GRE_ZONE")
      s = resultSet.getString("GRE_START_RANGE_VALUE")
      e = resultSet.getString("GRE_END_RANGE_VALUE")
      if (s != null) {
        startRange = s.toDouble;

      }
      if (e != null) {
        endRange = e.toDouble
      }

      if (IsZone != null && IsZone.equalsIgnoreCase("Y")) {
        isEnable = true
      }
      println("Green ZONE " + isEnable);
      println("Green ZONE " + IsZone);
      val greenAlert: Green = Green(isEnable, startRange, endRange)

      IsZone = resultSet.getString("IS_RED_ZONE")
      s = resultSet.getString("RED_START_RANGE_VALUE")
      e = resultSet.getString("RED_END_RANGE_VALUE")

      if (s != null) {
        startRange = s.toDouble;

      }
      if (e != null) {
        endRange = e.toDouble
      }

      if (IsZone != null && IsZone.equalsIgnoreCase("Y")) {
        isEnable = true
      }
      println("IS_RED_ZONE ZONE " + isEnable);
      println("IS_RED_ZONE ZONE " + IsZone);
      val redAlert: Red = Red(isEnable, startRange, endRange)

      var startTime: Long = 0;
      var endTime: Long = 0

      if (slaTimeRef != null) {
        // println("slaTimeRef "+ slaTimeRef + slaTimeRef.equalsIgnoreCase("Last completed period"))
        if (slaTimeRef.equalsIgnoreCase("Last completed period")) {
          if (timePeriod != null && (timePeriod.toLowerCase.indexOf("m") >= 0)) {
            val month: Int = timePeriod.toLowerCase.replace("m", "").toInt
            startTime = DateUtil.findStartOfMonth(-month, -1).getTime
            endTime = DateUtil.findEndOfMonth(-1, -1).getTime
            DateUtil.print(startTime)
            DateUtil.print(endTime)

          } else if (timePeriod != null && (timePeriod.indexOf("y") > -1 || timePeriod.indexOf("ys") > -1)) {
            val year: Int = timePeriod.toLowerCase.replace("y", "").toInt
            startTime = DateUtil.findStartOfMonth(-12, -1).getTime
            endTime = DateUtil.findEndOfMonth(-1, -1).getTime

          } else {
            //NULL
          }

        } else if (slaTimeRef.equalsIgnoreCase("Fixed interval")) {
          //2017-10-07 19:37:48.000965
          // println("timeRefFrom  "+ timeRefFrom)
          // println("timeRefTo  "+ timeRefTo)
          startTime =  DateUtil.parseDate(timeRefFrom, "dd-MMM-yy hh.mm.ss.SSSSSS a").getTime //timeRefFrom.getTime;
          endTime =  DateUtil.parseDate(timeRefTo, "dd-MMM-yy hh.mm.ss.SSSSSS a").getTime //timeRefTo.getTime;
        }

      }

      data += SLAPeriod(pk, slaType, clientIdRef, clientNameRef, slaTimeRef, startTime, endTime, fileTypeRef, timePeriod, redAlert, greenAlert, yellowAlert, slaOldValue, slaName, description)
      }
    if (connection != null)
      connection.close()
    return data;
  }

  def findAlertInfo(slaName: String): ArrayBuffer[AlertInfo] = {
    println("********** Find Alert **************")
    println("********** " + slaName + " **************")
    var connection: Connection = getConnection();
    //if(alertInfo==null){
    alertInfo = connection.prepareStatement("SELECT * FROM FILEGPS.PETPE_ALERT WHERE SLA_NAME=?")
    //}
    alertInfo.setString(1, slaName)
    var alertDetail: ArrayBuffer[AlertInfo] = ArrayBuffer[AlertInfo]();
    val resultSet: ResultSet = alertInfo.executeQuery();
    if (resultSet.next()) {
      val alertName: String = resultSet.getString("ALERT_NAME");
      val condition: String = resultSet.getString("CONDITION");
      val description: String = resultSet.getString("DESCRIPTION");
      val priority: String = resultSet.getString("PRIORITY");
      val period: String = resultSet.getString("TIME_PERIOD");
      val notificationFreqency: String = resultSet.getString("NOTIFI_FR");
      val notificationStart: String = resultSet.getString("NOTIF_START_DT");
     val notificationStartDt:java.util.Date=DateUtil.parseDate(notificationStart, "dd-MMM-yy hh.mm.ss.SSSSSS a")
      alertDetail += AlertInfo(alertName, condition, description, priority, period, notificationFreqency, new Date(notificationStartDt.getTime))
    }
    resultSet.close()
    connection.close()
    return alertDetail;
  }
  def findClientInfo(client: String): ClientInfo = {
    var connection: Connection = getConnection();
    //SELECT  CLIENT_NAME, CLIENT_ID, SUCCESS_PERCENTAGE FROM PETPE_CLIENT WHERE CLIENT_NAME='ptagma1'
    // if(psmt==null){
    psmt = connection.prepareStatement("SELECT  CLIENT_NAME, CLIENT_ID, SUCCESS_PERCENTAGE FROM FILEGPS.PETPE_CLIENT WHERE CLIENT_NAME=?")
    //}
    psmt.setString(1, client)
    var clientInfo: ClientInfo = null;
    val resultSet: ResultSet = psmt.executeQuery()
    if (resultSet.next()) {
      //  println(resultSet.getString(1))
      // println(resultSet.getString(2))
      // println(resultSet.getString(3))
      clientInfo = ClientInfo(resultSet.getString(1), resultSet.getString(2), resultSet.getString(3))
    }
    if (connection != null)
      connection.close();
    return clientInfo;
  }

  def updateClientSLA(slaAvg: Double, sla: SLAPeriod): Unit = {
    var connection: Connection = getConnection();
    connection.setAutoCommit(true)
    // if(updatePsmt==null){
    // updatePsmt = connection.prepareStatement("UPDATE  PETPE_SLA SET SLA_VALUE=?, TIME_REF_FROM=?, TIME_REF_TO=?, SLA_OLD_VALUE=? WHERE CLIENT_ID=? and PK_ID=?")

    updatePsmt = connection.prepareStatement("UPSERT INTO FILEGPS.PETPE_SLA(ROWKEY,CLIENT_ID,SLA_VALUE,TIME_REF_FROM,TIME_REF_TO,SLA_OLD_VALUE) VALUES(?,?,?,?,?,?)")
    // }
    //  println(DateUtil.parseDate(sla.timeRefFrom, "yyyy-MM-dd HH:mm:ss.S"))
    //  println(DateUtil.parseDate(sla.timeRefTo, "yyyy-MM-dd HH:mm:ss.S"))
    updatePsmt.setString(1, sla.pk)
    updatePsmt.setString(2, sla.clientIdRef)
    if (sla.slaType != null && sla.slaType.equalsIgnoreCase("D")) {
      updatePsmt.setString(3, (slaAvg.toLong) + "")

    } else {
      updatePsmt.setString(3, slaAvg + "")
    }
    
    updatePsmt.setString(4, DateUtil.formatDate(sla.timeRefFrom, "dd-MMM-yy hh.mm.ss.SSSSSS a"))
    updatePsmt.setString(5, DateUtil.formatDate(sla.timeRefTo, "dd-MMM-yy hh.mm.ss.SSSSSS a"))
    updatePsmt.setString(6, sla.slaOldValue)
    println("FILEGPS.PETPE_SLA Insertion Details: FILEGPS.PETPE_SLA" + sla.pk + " sla.clientIdRef: " + sla.clientIdRef + "slaAvg:  " + slaAvg + " sla.slaOldValue: " + sla.slaOldValue)
    connection.commit()

    val updateCount: Int = updatePsmt.executeUpdate();
    // Add alter svaed.
    val alertInfo: ArrayBuffer[AlertInfo] = findAlertInfo(sla.slaName)
    if (alertInfo != null) {
      alertInfo.foreach(alert => {
        generateAlert(alert, sla, slaAvg);
      })
    }

    if (connection != null)
      connection.close();
  }

  def generateAlert(alertInfo: AlertInfo, sla: SLAPeriod, slaAvg: Double) = {

    /*if(sla.greenAlert!=null && sla.greenAlert.enable && slaAvg >=sla.greenAlert.startRange && slaAvg <=sla.greenAlert.endRange){
      insertAlert(alertInfo, sla, Alert(UniqueIdentifier.generate(8), "Green Alert", slaAvg, sla.clientIdRef, sla.clientName))
    } else  if(sla.yellowAlert!=null && sla.yellowAlert.enable && slaAvg >=sla.yellowAlert.startRange && slaAvg <= sla.yellowAlert.endRange){
      insertAlert(alertInfo, sla,Alert(UniqueIdentifier.generate(8), "Yellow Alert", slaAvg, sla.clientIdRef, sla.clientName))

    } else if(sla.redAlert!=null && sla.redAlert.enable && slaAvg >=sla.redAlert.startRange && slaAvg <= sla.redAlert.endRange){
      insertAlert(alertInfo, sla,Alert(UniqueIdentifier.generate(8), "Red Alert", slaAvg, sla.clientIdRef, sla.clientName))
    }
*/
    println("....**********......" + alertInfo)
    //
    if (alertInfo != null) {

      println("....********** :" + alertInfo.condition + ":....********** :")
      alertInfo.condition match {
        case "Above Yellow" => {

          if (sla.yellowAlert != null && sla.yellowAlert.enable && slaAvg >= sla.yellowAlert.startRange && slaAvg <= sla.yellowAlert.endRange) {
            var result: Int = com.Common.compareDate(alertInfo.notificationStartDt, new java.util.Date());
            if (result <= 0) {
              insertAlert(alertInfo, sla, Alert(UniqueIdentifier.generate(8), "Above Yellow Alert", slaAvg, sla.clientIdRef, sla.clientName))
            }

          }
        }
        case "Below Yellow" => {

          if (sla.redAlert != null && sla.redAlert.enable && slaAvg <= sla.yellowAlert.startRange) {
            var result: Int = com.Common.compareDate(alertInfo.notificationStartDt, new java.util.Date());
            if (result == 0 || result == -1) {
              insertAlert(alertInfo, sla, Alert(UniqueIdentifier.generate(8), "Below Yellow Alert", slaAvg, sla.clientIdRef, sla.clientName))
            }
          }
        }
        case "Below Green" => {
          println("....**********Below Green......")
          if (sla.greenAlert != null && sla.greenAlert.enable && slaAvg <= sla.greenAlert.startRange) {
            var result: Int = com.Common.compareDate(alertInfo.notificationStartDt, new java.util.Date());
            if (result <= 0) {
              insertAlert(alertInfo, sla, Alert(UniqueIdentifier.generate(8), "Below Green", slaAvg, sla.clientIdRef, sla.clientName))
            }
          }
        }
        case "Below Red" => {
          println("....**********Below Below......")
          if (sla.redAlert != null && sla.redAlert.enable && slaAvg >= sla.redAlert.startRange && slaAvg <= sla.redAlert.endRange) {
            insertAlert(alertInfo, sla, Alert(UniqueIdentifier.generate(8), "Below Red", slaAvg, sla.clientIdRef, sla.clientName))
          }
        }
        case _ => {

        }
      }
    }

  }
  def insertAlert(alertInfo: AlertInfo, sla: SLAPeriod, alert: Alert): Unit = {
    var connection: Connection = getConnection();
    connection.setAutoCommit(true)
    //  if(alertInsert==null){
    alertInsert = connection.prepareStatement("UPSERT INTO FILEGPS.PETPE_ALL_ALERTS (PK_ID, ALERT_NAME, DESCRIPTION, SLA_NAME, PRIORITY, CONDITION, " +
      "PERIOD, CLIENT_NAME, CLIENT_ID, ALERT_VALUE, TIMESTAMP) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")
    // }
    println("FILEGPS.PETPE_ALL_ALERTS: alert.pk: " + alert.pk + "alertInfo.alertName: " + alertInfo.alertName + "alert.clientName: " + alert.clientName + "sla.slaName: " + sla.slaName)
    alertInsert.setString(1, alert.pk) //PK
    alertInsert.setString(2, alertInfo.alertName) //PK
    alertInsert.setString(3, alertInfo.description) //PK
    alertInsert.setString(4, sla.slaName) //PK
    alertInsert.setString(5, alertInfo.priority) //PK
    alertInsert.setString(6, alertInfo.condition) //PK
    alertInsert.setString(7, alertInfo.period) //PK
    alertInsert.setString(8, alert.clientName) //PK
    alertInsert.setString(9, alert.clientId) //PK
    alertInsert.setString(10, alert.value + "") //PK
    alertInsert.setTimestamp(11, new Timestamp(new java.util.Date().getTime)) //PK
    alertInsert.execute()
    connection.commit()
    println("*-----*insertion of sla alert into PETPE_ALL_ALERTS completed*----")
    if (connection != null)
      connection.close()
    try {
      val mail = new EmailUtil.Mail(
        from = "vijay.reddy@pragmaedge.com",
        to = Seq("harinath.chalamala@pragmaedge.com","vijay.reddy@pragmaedge.com"),
        subject = "Alert Information",
        message = "Alert Details:\nAlert Name: " + alertInfo.alertName + "\nAlert Description: " + alertInfo.description + "\nSLA Name: " + sla.slaName)
      EmailUtil.sendMail(mail)
       println("*-----*SLA ALERT EMAIL SENT*----")
    } catch {
      case e: Exception => e.printStackTrace()
    }
  }
  
  def subscriptionAlert(client_name:String,client_id:String,event_type:String):Subscription_Alert={
    
     println("*-----*def subscriptionAlert: client_name: "+client_name+"client_id: "+ client_id+"event_type: "+event_type+"*----")
    var connection: Connection = getConnection();
    var subscriptionAlert :Subscription_Alert= null
    var subscriptionKey = client_name+"_"+client_id
    //if(alertInfo==null){
    subscriptionInfo = connection.prepareStatement("SELECT SUBSCRIPTION_ID,CLIENT_ID,CLIENT_NAME,EVENT_TYPE,FILE_TYPE,FILE_NAME_PATTERN,EMAIL_ADDRESS FROM FILEGPS.SUBSCRIPTION_ALERT WHERE SUBSCRIPTION_ID=? and EVENT_TYPE=?")
    //}
    subscriptionInfo.setString(1, subscriptionKey)
     subscriptionInfo.setString(2, event_type)
    val resultSet: ResultSet = subscriptionInfo.executeQuery()
   
    if (resultSet.next()) {
      //  println(resultSet.getString(1))
      // println(resultSet.getString(2))
      // println(resultSet.getString(3))
      println("*-----*SUBSCRIPTION_ALERT: SELECT STMT RESLT "+resultSet.getString(1)+" "+ resultSet.getString(2)+" "+ resultSet.getString(3)+" "+resultSet.getString(4)+" "+resultSet.getString(5)+" "+resultSet.getString(6)+" "+resultSet.getString(7)+"*------*")
      subscriptionAlert = Subscription_Alert(resultSet.getString(1), resultSet.getString(2), resultSet.getString(3),resultSet.getString(4),resultSet.getString(5),resultSet.getString(6),resultSet.getString(7))
    }
    errorInsertAlert(subscriptionAlert)
    //emails need to be changed once after creating the column in sla table
        try {
      val mail = new EmailUtil.Mail(
        from = "vijay.reddy@pragmaedge.com",
        to = Seq(subscriptionAlert.Email_Address),
        subject = "Error Subscription Alert",
        message = "Error Subscription Alert Details:\nClient ID: " + subscriptionAlert.Client_ID + "\nClient Name: " + subscriptionAlert.Client_Name + "\nEvent Type: " + subscriptionAlert.Event_Type)
      EmailUtil.sendMail(mail)
       println("*-----*ERROR EMAIL SENT*----")
    } catch {
      case e: Exception => e.printStackTrace()
    }
    
    if (connection != null)
      connection.close();
    return subscriptionAlert;
  }  
  
  //Subscription Alerts insert into ALL_ALERTS TABLE
  
  def errorInsertAlert(subAlert:Subscription_Alert): Unit = {
    var connection: Connection = getConnection();
    connection.setAutoCommit(true)
    //  if(alertInsert==null){
    alertInsert = connection.prepareStatement("UPSERT INTO FILEGPS.PETPE_ALL_ALERTS (PK_ID, ALERT_NAME, DESCRIPTION, PRIORITY, " +
      "CLIENT_NAME, CLIENT_ID, TIMESTAMP) VALUES (?, ?, ?, ?, ?, ?, ?)")
    // }
    println("*-----*ERROR SUB_ALERT: FILEGPS.PETPE_ALL_ALERTS: subAlert.Subscription_ID: " + subAlert.Subscription_ID + "subAlert.Event_Type: " + subAlert.Event_Type + "subAlert.Client_Name: " + subAlert.Client_Name + "subAlert.Client_ID: " + subAlert.Client_ID)
    alertInsert.setString(1, subAlert.Subscription_ID)
    alertInsert.setString(2, "ERROR ALERT") 
    alertInsert.setString(3, "ERROR IN "+ subAlert.Event_Type + " EVENT")
    alertInsert.setString(4, "1") 
    alertInsert.setString(5, subAlert.Client_Name) 
    alertInsert.setString(6, subAlert.Client_ID) 
    alertInsert.setTimestamp(7, new Timestamp(new java.util.Date().getTime)) 
    alertInsert.execute()
    connection.commit()
     println("*-----*INSERTED ERROR RECORD INTO  FILEGPS.PETPE_ALL_ALERTS")

    if (connection != null)
      connection.close()}
  
  
  //get the ordered_event_data table columns in phoenix and creates a map. 
  def currentTableSchema():scala.collection.mutable.Map[String,String]={
     var connection: Connection = getConnection();
     
      var oldschema:Map[String,String] =null
       println("*-----*IN def currentTableSchema  *----*")
     jsonSchemaverify= connection.prepareStatement("SELECT * FROM ORDER_EVENTS_DATA")
     val resultSet: ResultSet = jsonSchemaverify.executeQuery()
    val  metaData :ResultSetMetaData= resultSet.getMetaData();
     val col_count:Int=metaData.getColumnCount()
     var i:Int =0;
     val map = scala.collection.mutable.Map[String,String]()
    // Vector<String> columnNames = new Vector<String>();
     
     for (i <- 1 to  col_count) {
         var name:String =metaData.getColumnName(i);
         var coltype:String = metaData.getColumnTypeName(i)
           println("*-----*"+ i +". metaData.getColumnName(i):" +metaData.getColumnName(i)+"metaData.getColumnTypeName"+ metaData.getColumnTypeName(i)+"*-----*")
         map.put(name.toLowerCase(), coltype)
      }
     
      if (connection != null)
      connection.close()
          return map
      }
  
  //ALtert the view of ORDERED_EVENTS_DATA if there is any change in the JSON schema
  def alterEventSchema(newfields:scala.collection.mutable.Map[String,String])={
      var connection: Connection = getConnection();
      connection.setAutoCommit(true)
       var alterschemastatus:Int = 0
      
    newfields.foreach{case(k,v) => 
     println("----*DEF ALERTEVENTSCHEM FOR ALTER QUERY:KEY(COL_NAME)-->"+ k + "VALUE(COL_TYPE)--> " + v)
     println("ALTER VIEW ORDER_EVENTS_DATA ADD IF NOT EXIST "+ "\"event\"."+ "\""+k +"\" VARCHAR")
    alterschemastatus = connection.prepareStatement("ALTER VIEW ORDER_EVENTS_DATA ADD IF NOT EXISTS "+ "\"event\"."+ "\""+k +"\" VARCHAR").executeUpdate()}
    //need to update the phoenix map once after the alter view
    println("alterschemastatus_: "+alterschemastatus)
      if(alterschemastatus == 0){
    println("*----* ALTERED ORDERED_EVENTS_DATA")
    currentTableSchema()
    println("*----* UPDATED MAP WITH NEW COLUMNS")
    }
     if (connection != null)
      connection.close()
           
  }
  
  
  
}