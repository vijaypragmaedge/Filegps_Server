package com.spark.kafka

import java.util

import kafka.serializer.StringDecoder
import org.apache.hadoop.hbase.HBaseConfiguration
import org.apache.hadoop.hbase.client._
import org.apache.hadoop.hbase.filter.CompareFilter.CompareOp
import org.apache.hadoop.hbase.filter.{FilterList, SingleColumnValueFilter}
import org.apache.hadoop.hbase.util.Bytes
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.apache.spark.streaming.kafka.KafkaUtils

object SparkHBaseUnOrderClientBak {
  def main(args: Array[String]) = {
    val kafkaBroker = args(0) //"localhost:9092"
    val zk = args(1)
    val topic = args(2)
    val conf = new SparkConf()
      .setAppName("SparkHBaseStream")
      .setMaster("local[4]")

    val sc = new SparkContext(conf)
    val ssc = new StreamingContext(sc, Seconds(5))
    val topics = Array(topic).toSet;
    val kafkaParams = Map[String, String]("metadata.broker.list" -> kafkaBroker, "group.id" -> "group1");
    var kafkaStream = KafkaUtils.createDirectStream[String, String, StringDecoder, StringDecoder](ssc, kafkaParams, topics)
    var inputStream = kafkaStream.map(_._2);
    inputStream = inputStream.repartition(12);
    /*val parsedStream = inputStream.mapPartitions {
      rows =>
        rows.map { row =>

        }
    }*/
    inputStream.foreachRDD(rdd => if (!rdd.isEmpty()) rdd.foreach(row => linkUnOrderData(zk)))
    ssc.start()
    ssc.awaitTermination()

  }

  def linkUnOrderData(zk:String) {
    val hConf = HBaseConfiguration.create()
    hConf.set("hbase.zookeeper.quorum", zk)
    val tableName = "ORDER_EVENTS_DATA"
    val unOrderedEvent = "UN_ORDER_EVENTS_DATA"
    // Initialize hBase table if necessary

    val hTable = new HTable(hConf, tableName)
    val unOrderedEventTable = new HTable(hConf, unOrderedEvent)
    val scan: Scan = new Scan();
    val allFilters: FilterList = new FilterList(FilterList.Operator.MUST_PASS_ALL)
    val f1: SingleColumnValueFilter = new SingleColumnValueFilter(Bytes.toBytes("event"), Bytes.toBytes("co_relation_id"), CompareOp.EQUAL, Bytes.toBytes("EMPTY"))
    allFilters.addFilter(f1);
    scan.setFilter(allFilters);
    val result :ResultScanner= unOrderedEventTable.getScanner(scan);
    val iter = result.iterator();
    while(iter.hasNext){
      val r:Result  = iter.next()
      val e:Event = new Event();
      var get:Get = new Get(r.getRow)
      get = get.addFamily(Bytes.toBytes("event"))
      val found:Result = hTable.get(get)
      val puts:util.List[Put] = new util.ArrayList[Put]()
      puts.add(new Put(get.getRow))
      val msgTxt  : String = Bytes.toString(found.getValue(e.cfDataBytes, e.msgTxtBytes));
      var coRelation: String = null;
      if(msgTxt!=null && !msgTxt.equalsIgnoreCase("stop")) {
        coRelation = findStartOfEvent(found, puts, hTable);
        if(coRelation!=null) {
          val it:util.Iterator[Put] = puts.iterator()
          val deletes:util.List[Delete] = new util.ArrayList[Delete]()
          while(it.hasNext) {
            val p : Put = it.next();
            p.add(e.cfDataBytes, e.corelationId, Bytes.toBytes(coRelation))
            deletes.add(new Delete(p.getRow))
          }     //coRelation = findStopOfEvent(hTable.get(get), puts, hTable)

          hTable.put(puts)
          hTable.flushCommits();
          deletes.add(new Delete(found.getRow))
          unOrderedEventTable.delete(deletes)
          unOrderedEventTable.flushCommits();
        }
      } else {
        //TODO: handle stop event

        coRelation = findStopOfEvent(found, puts, hTable, false);
        if(coRelation!=null) {
          val deletes:util.List[Delete] = new util.ArrayList[Delete]()
          val it:util.Iterator[Put] = puts.iterator()
          while(it.hasNext) {
            val p : Put = it.next();
            p.add(e.cfDataBytes, e.corelationId, Bytes.toBytes(coRelation))
            deletes.add(new Delete(p.getRow))
          }     //coRelation = findStopOfEvent(hTable.get(get), puts, hTable)


          hTable.put(puts)
          hTable.flushCommits();

          deletes.add(new Delete(found.getRow))
          unOrderedEventTable.delete(deletes)
        }

      }

    }
    println("Saved.")
  }

  def findStartOfEvent(r:Result, list:util.List[Put], hTable:HTable) : String = {
    var coRelationId:String = null;
    val e:Event = new Event();
    if(r!=null && Bytes.toString(r.getValue(e.cfDataBytes, e.nodeIdBytes))!=null) {
      val nodes :Array[String] = Bytes.toString(r.getValue(e.cfDataBytes, e.nodeIdBytes)).split("/")
      val r1:String = nodes(0)
      val r2:String = Bytes.toString(r.getValue(e.cfDataBytes, e.localFileNameBytes))
      val rowKey:String = r1 + "_"+r2;
      var get:Get = new Get(Bytes.toBytes(rowKey))
      get = get.addFamily(Bytes.toBytes("event"))
      val found:Result = hTable.get(get)
      coRelationId = Bytes.toString(found.getValue(e.cfDataBytes, e.corelationId))
      val msgTxt  : String = Bytes.toString(found.getValue(e.cfDataBytes, e.msgTxtBytes));
      if(msgTxt!=null && !msgTxt.equalsIgnoreCase("start")){
        list.add(new Put(found.getRow))
        coRelationId = findStartOfEvent(found, list, hTable);
      }
      else {
        return coRelationId;
      }

    }
    return coRelationId;

  }

  def findStopOfEvent(r:Result, list:util.List[Put], hTable:HTable, include:Boolean) : String = {
    var coRelationId:String = null;
    val e:Event = new Event();
    if(r!=null && Bytes.toString(r.getValue(e.cfDataBytes, e.nodeIdBytes))!=null) {
      val nodes :Array[String] = Bytes.toString(r.getValue(e.cfDataBytes, e.nodeIdBytes)).split("/")
      var r1:String = nodes(1)
      if(include)
        r1= nodes(0)
      val r2:String = Bytes.toString(r.getValue(e.cfDataBytes, e.localFileNameBytes))
      val rowKey:String = r1 + "_"+r2;

      var get:Get = new Get(Bytes.toBytes(rowKey))
      get = get.addFamily(Bytes.toBytes("event"))
      val found:Result = hTable.get(get)
      coRelationId = Bytes.toString(found.getValue(e.cfDataBytes, e.corelationId))

      System.out.println(coRelationId+ " Ms g Text " +Bytes.toString(found.getValue(e.cfDataBytes, e.msgTxtBytes)) );

      val msgTxt  : String = Bytes.toString(found.getValue(e.cfDataBytes, e.msgTxtBytes));
      if(msgTxt!=null && !msgTxt.equalsIgnoreCase("start")){
        list.add(new Put(found.getRow))
        // if(coRelationId==null || (coRelationId!=null && coRelationId.equalsIgnoreCase("empty"))) {
        coRelationId = findStopOfEvent(found, list, hTable, true);
        //}
      }else {

        return coRelationId;
      }


    }
    return coRelationId;

  }
}
