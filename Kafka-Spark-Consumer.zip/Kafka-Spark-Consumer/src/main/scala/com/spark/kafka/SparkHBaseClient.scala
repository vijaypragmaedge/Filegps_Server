package com.spark.kafka

import java.util
import java.util.Iterator
import scala.collection.JavaConversions.mapAsScalaMap
import kafka.serializer.StringDecoder
import org.apache.hadoop.hbase.{ HBaseConfiguration, TableName }
import org.apache.hadoop.hbase.client._
import org.apache.hadoop.hbase.util.Bytes
import org.apache.kafka.clients.producer.{ KafkaProducer, ProducerConfig, ProducerRecord }
import org.apache.spark.streaming.{ Seconds, StreamingContext }
import org.apache.spark.streaming.kafka.KafkaUtils
import org.apache.spark.{ SparkConf, SparkContext }
import java.util.Arrays.ArrayList

class SparkHBaseClient {

}

object SparkHBaseClient {
  var url: String = "org.apache.phoenix.jdbc.PhoenixDriver"
  val phoenixjdbcclt: PhoenixJdbcClient = new PhoenixJdbcClient(url, "FILEGPS", "QbHMTP7V")
  def main(args: Array[String]) = {

    // val phoenixjdbcclt:PhoenixJdbcClient = new PhoenixJdbcClient()
    val kafkaBroker = args(0) //"localhost:9092"
    val zk = args(1) 
    val topic = args(2)
    val unOrderTp = args(3) //unorder topic
    val oracleDurationCalculationTopic = args(4) //calculate stop topic listener
    println("*** consuming data")
    val conf = new SparkConf()
      .setAppName("SparkHBaseStream")
      .setMaster("local[4]")

    val sc = new SparkContext(conf)
    val ssc = new StreamingContext(sc, Seconds(5))
    val phoenixEventschema: scala.collection.mutable.Map[String, String] = phoenixjdbcclt.currentTableSchema()
    phoenixEventschema.keys.foreach { x =>
      println("*--current view columns---* " + x)
    }
    sc.broadcast(phoenixEventschema)
    val topics = Array(topic).toSet;
    val kafkaParams = Map[String, String]("metadata.broker.list" -> kafkaBroker, "group.id" -> "group1");
    var kafkaStream = KafkaUtils.createDirectStream[String, String, StringDecoder, StringDecoder](ssc, kafkaParams, topics)
    var inputStream = kafkaStream.map(_._2);

    inputStream = inputStream.repartition(12);
    val parsedStream = inputStream.mapPartitions {
      rows =>
        rows.map { row =>
          println("Row value.." + row)
          Event.parse(row)

        }
    }

    val Hbase_inset = parsedStream.foreachRDD(rdd => if (!rdd.isEmpty()) rdd.foreach(row => toHBase(row, kafkaBroker, unOrderTp, oracleDurationCalculationTopic)))
    val update_phoenix_view = parsedStream.foreachRDD(rdd => if (!rdd.isEmpty()) rdd.foreach(row => compareEventSchema(row, phoenixEventschema)))
    ssc.start()
    ssc.awaitTermination()

  }
  def compareEventSchema(eventMap: Event, phoenixSchema: scala.collection.mutable.Map[String, String]) = {
    // val diff : Map[String, String] = phoenixSchema.keySet() -- colors2.keySet*/
    val similarItems = scala.collection.mutable.Set[String]()
    var newfields: scala.collection.mutable.Map[String, String] = scala.collection.mutable.Map.empty[String, String]
    eventMap.getMap.keys.foreach { key =>
      println("*-------*eventMap map: keys--> " + key)

      if (!phoenixSchema.contains(key.toLowerCase())) {
        newfields.put(key, "VARCHAR")
        println("*-------*new fields: col--> " + key + " type--> " + "VARCHAR")
      }
    }

    if (!newfields.isEmpty) { phoenixjdbcclt.alterEventSchema(newfields) }
  }

  def toHBase(eventMap: Event, kafkaBroker: String, unOrderTp: String, oracleDurationCalculationTopic: String) {
    
    
    val props = new util.HashMap[String, Object]()
    props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaBroker)
    props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,
      "org.apache.kafka.common.serialization.StringSerializer")
    props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,
      "org.apache.kafka.common.serialization.StringSerializer")
    //checks for error event
 /*   if (eventMap.getMap().containsKey("errorInfo")) {
      val clientName: String = eventMap.getMap().get("clientName").toString()
      val clientId: String = eventMap.getMap().get("clientId").toString()
      val evenType: String = eventMap.getMap().get("msgTxt").toString()
      phoenixjdbcclt.subscriptionAlert(clientName, clientId, evenType)
    }*/

    val producer = new KafkaProducer[String, String](props)
    val hConf = HBaseConfiguration.create()
    hConf.set("hbase.zookeeper.quorum", "localhost:2181")
    val tableName = "ORDER_EVENTS_DATA"
    val unOrderedEvent = "UN_ORDER_EVENTS_DATA"
    // Initialize hBase table if necessary

    val admin = new HBaseAdmin(hConf)
    if (!admin.isTableAvailable(tableName)) {
      import org.apache.hadoop.hbase.{ HColumnDescriptor, HTableDescriptor }
      var family = new HColumnDescriptor(Bytes.toBytes("event"))
      var tableDesc = new HTableDescriptor(TableName.valueOf(tableName))
      tableDesc.addFamily(family);
      admin.createTable(tableDesc)

      family = new HColumnDescriptor(Bytes.toBytes("event"))
      tableDesc = new HTableDescriptor(TableName.valueOf(unOrderedEvent))
      tableDesc.addFamily(family);
      admin.createTable(tableDesc)
    }
    if (!admin.isTableAvailable(unOrderedEvent)) {
      import org.apache.hadoop.hbase.{ HColumnDescriptor, HTableDescriptor }
      var family = new HColumnDescriptor(Bytes.toBytes("event"))
      var tableDesc = new HTableDescriptor(TableName.valueOf(unOrderedEvent))
      tableDesc.addFamily(family);
      admin.createTable(tableDesc)

    }
    val hTable = new HTable(hConf, tableName)
    val unOrderedEventTable = new HTable(hConf, unOrderedEvent)
     var rowKey: String = ""
    if (!eventMap.getMap().get("msgTxt").toString.equalsIgnoreCase("start")) {
      val nodes: Array[String] = eventMap.getMap().get("nodeId").toString.split("/")
      if(eventMap.getMap().get("msgTxt").toString.equalsIgnoreCase("Reprocess")){
        rowKey = nodes(1) + "_" + "null"
       println(" rowKey;l  " + rowKey)
      }else{
      rowKey = nodes(0) + "_" + eventMap.getMap().get("localFileName")
      println(" rowKey  " + rowKey)
      }
      var get: Get = new Get(Bytes.toBytes(rowKey))
      //  get.setClosestRowBefore()
      get = get.addFamily(Bytes.toBytes("event"))
      var result: Result = hTable.get(get)
      val coRelationId = Bytes.toString(result.getValue(eventMap.cfDataBytes, eventMap.corelationId))
      val sub_co_relation_id = Bytes.toString(result.getValue(eventMap.cfDataBytes, Bytes.toBytes("sub_co_relation_id")))
      println("sub_co_relation_id - inside not in start if : -" + sub_co_relation_id)
      System.out.printf("\t%s = %s\n", rowKey, coRelationId)
      System.out.printf("\t%s = %s\n", rowKey, sub_co_relation_id)
      var put: Put = eventMap.convertMapToPut()
      println("after put")
       if(sub_co_relation_id !=null){
        println("sub_co_relation_id -inside if")
        put.addColumn(eventMap.cfDataBytes, Bytes.toBytes("sub_co_relation_id"),Bytes.toBytes(sub_co_relation_id))
        hTable.put(put) 
     }
      println(" coRelationId " + coRelationId)
      if (coRelationId == null || coRelationId.equalsIgnoreCase("EMPTY")) {
        put.addColumn(Bytes.toBytes("event"), Bytes.toBytes("duration"), Bytes.toBytes(100 + ""))
        // hTable.put(put)
        // unOrderedEventTable.delete(new Delete(Bytes.toBytes(rowKey)))
        result = unOrderedEventTable.get(get)
        val data: Array[Byte] = result.getValue(eventMap.cfDataBytes, Bytes.toBytes("event_type"))
        if (!result.isEmpty && data != null && Bytes.toString(data).equalsIgnoreCase("1-To-M")) {
          var nodeId: String = eventMap.getMap.get("nodeId").toString
          val nodes = nodeId.split("/")
          var child: Put = new Put(Bytes.toBytes(rowKey))
          child.addColumn(Bytes.toBytes("event"), Bytes.toBytes("duration"), Bytes.toBytes(100 + ""))
          val localFileName = eventMap.getMap.get("remoteFileName").toString
       //   val sub_co_relation_id = eventMap.getMap.get("sub_co_relation_id").toString

          child = eventMap.convert1toM("remoteFileName1", child)
          child.addColumn(eventMap.cfDataBytes, Bytes.toBytes("sub_co_relation_id"), Bytes.toBytes(sub_co_relation_id))
          unOrderedEventTable.delete(new Delete(Bytes.toBytes(rowKey)))
          unOrderedEventTable.put(child);
          unOrderedEventTable.flushCommits();
        } else {
          unOrderedEventTable.put(put);
          unOrderedEventTable.flushCommits();
        }
        // hTable.flushCommits();
        //TODO:Notify Kafka
        try {
          val message = new ProducerRecord[String, String](unOrderTp, "192.168.1.10", eventMap.toString)
          producer.send(message)
        } catch {
          case e: Exception => {
            println(e)
          }
        }

      } else {
        if (!result.isEmpty()) {
          put = eventMap.convertMapToPut()
          val timeStart: Long = Bytes.toLong(result.getValue(eventMap.cfDataBytes, eventMap.timeStampBytes));
          val diff: Long = eventMap.getMap().get("timestamp").toString.toLong - timeStart;
          val duration: Long = (diff / (1000 * 60 * 60)) % 24
          put.addColumn(eventMap.cfDataBytes, eventMap.duration, Bytes.toBytes(diff + ""))
          put.addColumn(eventMap.cfDataBytes, eventMap.successValue, Bytes.toBytes(100 + ""))
          put.addColumn(eventMap.cfDataBytes, Bytes.toBytes("co_relation_id"), result.getValue(Bytes.toBytes("event"), Bytes.toBytes("co_relation_id")))
          put.addColumn(eventMap.cfDataBytes, Bytes.toBytes("sub_co_relation_id"), result.getValue(Bytes.toBytes("event"), Bytes.toBytes("sub_co_relation_id")))
        } //else {
        result = unOrderedEventTable.get(get)
        //Find out co-relation link if row is type of 1-to-m
        var isOne2M: Boolean = false;
        if (!result.isEmpty) {
          val data: Array[Byte] = result.getValue(eventMap.cfDataBytes, Bytes.toBytes("event_type"))
          if (data != null && Bytes.toString(data).equalsIgnoreCase("1-To-M")) {
            isOne2M = true;
            unOrderedEventTable.delete(new Delete(result.getRow))
            unOrderedEventTable.flushCommits();
            unOrderedEventTable.flushCommits();
          }
        }
        //}
        hTable.put(put)
        //  unOrderedEventTable.put(put);
        hTable.flushCommits();
        //unOrderedEventTable.flushCommits();
        //post mesasge to stop calculation listener
        if (eventMap.getMap.get("msgTxt").toString.equalsIgnoreCase("stop")) {
          try {
            println(" *********** Sending message to oracle topic *************************")
            val message = new ProducerRecord[String, String](oracleDurationCalculationTopic, "192.168.1.9", Bytes.toString(put.getRow))
            producer.send(message)
            println(" *********** Sending message to oracle topic : sent *************************")
          } catch {
            case e: Exception => {
              println(e)
            }
          }
        }
        //
      }

    } else {

      if (eventMap.getMap.get("msgTxt").toString.equalsIgnoreCase("start") && eventMap.getMap.containsKey("localFileName")) {
        if (eventMap.getMap.get("localFileName").toString.indexOf(".zip") > 0) {
          var put: Put = eventMap.convertMapToPut()
          put.addColumn(eventMap.cfDataBytes, Bytes.toBytes("event_type"), Bytes.toBytes("1-To-M"))
         // put.addColumn(eventMap.cfDataBytes, Bytes.toBytes("sub_co_relation_id"), Bytes.toBytes(UniqueIdentifier.generate(10)))
          hTable.put(put);
          hTable.flushCommits();
          val it = eventMap.getMap.entrySet.iterator
          var numberOfRemoteFilesCount = 1;
          while (it.hasNext()) {
            val entry = it.next
            println(" Key name :" + entry.getKey);
            println(" Key name :" + entry.getKey.startsWith("remoteFileName"));
            //  if(entry.getKey.startsWith("remoteFileName") && !entry.getKey.equalsIgnoreCase("remoteFileName1")) {
            if (entry.getKey.startsWith("remoteFileName") && !entry.getKey.equalsIgnoreCase("remoteFileName")) {
              var count = entry.getKey.replace("remoteFileName", "")
              println(" Remote file " + entry.getKey)
              println(" Remote count " + count)
              var nodeId: String = eventMap.getMap.get("nodeId" + count).toString
              val nodes = nodeId.split("/")
              var child: Put = new Put(Bytes.toBytes(nodes(1) + "_" + entry.getValue))
              var remoteFilenamevalue: String = eventMap.getMap.get("remoteFileName" + count).toString
              child = eventMap.convert1toM("remoteFileName", child)
              child.addColumn(eventMap.cfDataBytes, Bytes.toBytes("event_type"), Bytes.toBytes("1-To-M"))
              //put.getFamilyCellMap
              child.add(eventMap.cfDataBytes, Bytes.toBytes("remoteFileName"), Bytes.toBytes(remoteFilenamevalue))
              child.add(eventMap.cfDataBytes, Bytes.toBytes("nodeId"), Bytes.toBytes(nodeId))
              child.addColumn(eventMap.cfDataBytes, Bytes.toBytes("co_relation_id"), put.get(Bytes.toBytes("event"), Bytes.toBytes("co_relation_id")).get(0).getValue)
              child.addColumn(eventMap.cfDataBytes, Bytes.toBytes("sub_co_relation_id"), Bytes.toBytes(UniqueIdentifier.generate(10)))
              child.addColumn(eventMap.cfDataBytes, Bytes.toBytes("msgTxt"), Bytes.toBytes("Start"))

              hTable.put(child);
              hTable.flushCommits();

              unOrderedEventTable.put(child);
              unOrderedEventTable.flushCommits();
            }
          }

        } else {
          var put: Put = eventMap.convertMapToPut()
          hTable.put(put);
          hTable.flushCommits();
        }
      }

    }

    println("Saved.")

  }
}