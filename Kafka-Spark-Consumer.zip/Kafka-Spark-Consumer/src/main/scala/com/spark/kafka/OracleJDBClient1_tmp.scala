package com.spark.kafka

import java.sql.{Connection, _}
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

import scala.collection.mutable.{ArrayBuffer, ListBuffer}
import com.pragma.filegps.util.EmailUtil
import com.pragma.filegps.util.DateUtil
/*
case class ClientInfo (name:String, clientId:String, successValue:String)
case class SLAPeriod (pk:String, slaType:String,  clientIdRef:String, clientName:String,  slaTimeRef:String, timeRefFrom:Long,
                      timeRefTo:Long, fileTypeRef:String, slaTimePeriod:String, redAlert:Red, greenAlert:Green, yellowAlert:Yellow, slaOldValue:String, slaName:String, description:String)
case class Red(enable:Boolean, startRange:Double, endRange:Double)
case class Yellow(enable:Boolean, startRange:Double, endRange:Double)
case class Green(enable:Boolean, startRange:Double, endRange:Double)
case class Alert(pk:String, name:String, value:Double, clientId:String, clientName:String)
case class AlertInfo( alertName:String , condition:String,description:String, priority:String,period:String, notificationFreqency:String, notificationStartDt:Date )
*/
class OracleJDBClient1 (url:String, user:String, pass:String) extends Serializable {
 // var url:String = "jdbc:oracle:thin:@pcmdemo.care uhhgvzsm.us-east-1.rds.amazonaws.com:1521:ORCL"
  var psmt:PreparedStatement = null;
  var updatePsmt:PreparedStatement = null;
  var alertInsert:PreparedStatement = null;
  var alertInfo:PreparedStatement = null;

  def OracleJDBClient(url:String) = {
    Class.forName("oracle.jdbc.driver.OracleDriver");
  //  this.url = url;

  }

  def getConnection() : Connection= {
    return DriverManager.getConnection(url, user, pass)
  }

  def findSLAPeriod() :ListBuffer[SLAPeriod] = {
     var  connection:Connection = getConnection();
   // if(psmt==null){
      psmt = connection.prepareStatement("SELECT  PK_ID, CLIENT_ID_REF, SLA_TIME_REF, TIME_REF_FROM, TIME_REF_TO, FILE_TYPE_REF, TIME_REF_PERIOD, " +
        "IS_GRE_ZONE, IS_RED_ZONE, IS_YEL_ZONE,  RED_START_RANGE_VALUE, RED_END_RANGE_VALUE,  " +
        "YEL_START_RANGE_VALUE, YEL_END_RANGE_VALUE,  GRE_START_RANGE_VALUE, GRE_END_RANGE_VALUE, CLIENT_NAME_REF, TYPE_OF_SLA, SLA_VALUE, SLA_NAME, DESCRIPTION FROM PETPE_SLA")
   // }
    var clientInfo :ClientInfo = null;
    val resultSet:ResultSet = psmt.executeQuery()
    var data:ListBuffer[SLAPeriod] = new  ListBuffer[SLAPeriod]()
    while(resultSet.next()){
        val pk:String = resultSet.getString(1)
        val clientIdRef:String = resultSet.getString(2)
        val clientNameRef:String = resultSet.getString("CLIENT_NAME_REF")
        val slaTimeRef:String= resultSet.getString(3)
        val timeRefFrom:Date=resultSet.getDate(4)
        val timeRefTo:Date=resultSet.getDate(5)
        val fileTypeRef:String=resultSet.getString(6)
        val timePeriod:String=resultSet.getString(7)
        val slaType:String=resultSet.getString("TYPE_OF_SLA")
        val slaOldValue:String=resultSet.getString("SLA_VALUE")

        var IsZone:String=resultSet.getString("IS_YEL_ZONE")
        var s:String = resultSet.getString("YEL_START_RANGE_VALUE")
        var e:String = resultSet.getString("YEL_END_RANGE_VALUE")
        var slaName:String = resultSet.getString("SLA_NAME")
        var description:String = resultSet.getString("DESCRIPTION")

        var startRange: Double = 0;
        var endRange: Double = 0;
        if(s!=null){
          startRange = s.toDouble;

        }
        if(e!=null){
          endRange = e.toDouble
        }

        var isEnable :Boolean = false;
        if(IsZone!=null && IsZone.equalsIgnoreCase("Y")) {
          isEnable = true
        }
      println("IS_YEL_ZONE ZONE " + isEnable);
      println("IS_YEL_ZONE ZONE " + IsZone);
        val yellowAlert:Yellow = Yellow(isEnable, startRange, endRange)



      IsZone=resultSet.getString("IS_GRE_ZONE")
       s = resultSet.getString("GRE_START_RANGE_VALUE")
       e = resultSet.getString("GRE_END_RANGE_VALUE")
      if(s!=null){
        startRange = s.toDouble;

      }
      if(e!=null){
        endRange = e.toDouble
      }


      if(IsZone!=null && IsZone.equalsIgnoreCase("Y")) {
          isEnable = true
        }
      println("Green ZONE " + isEnable);
      println("Green ZONE " + IsZone);
        val greenAlert:Green = Green(isEnable, startRange, endRange)

      IsZone=resultSet.getString("IS_RED_ZONE")
      s = resultSet.getString("RED_START_RANGE_VALUE")
      e = resultSet.getString("RED_END_RANGE_VALUE")

      if(s!=null){
        startRange = s.toDouble;

      }
      if(e!=null){
        endRange = e.toDouble
      }

      if(IsZone!=null && IsZone.equalsIgnoreCase("Y")) {
          isEnable = true
        }
      println("IS_RED_ZONE ZONE " + isEnable);
      println("IS_RED_ZONE ZONE " + IsZone);
        val redAlert:Red = Red(isEnable, startRange, endRange)



      var startTime:Long = 0;
        var endTime:Long = 0

        if(slaTimeRef!=null){
         // println("slaTimeRef "+ slaTimeRef + slaTimeRef.equalsIgnoreCase("Last completed period"))
          if(slaTimeRef.equalsIgnoreCase("Last completed period")) {
              if(timePeriod!=null && (timePeriod.toLowerCase.indexOf("m") >=0)) {
                val month:Int = timePeriod.toLowerCase.replace("m", "").toInt
                startTime = DateUtil.findStartOfMonth(-month, -1).getTime
                endTime = DateUtil.findEndOfMonth(-1, -1).getTime
                DateUtil.print(startTime)
                DateUtil.print(endTime)

              } else  if(timePeriod!=null && (timePeriod.indexOf("y") > -1 || timePeriod.indexOf("ys")> -1)) {
                val year:Int = timePeriod.toLowerCase.replace("y", "").toInt
                startTime = DateUtil.findStartOfMonth(-12, -1).getTime
                endTime = DateUtil.findEndOfMonth(-1, -1).getTime

              } else {
                //NULL
              }

          }  else if(slaTimeRef.equalsIgnoreCase("Fixed interval")) {
              //2017-10-07 19:37:48.000965
           // println("timeRefFrom  "+ timeRefFrom)
           // println("timeRefTo  "+ timeRefTo)
             startTime = timeRefFrom.getTime;//  DateUtil.parseDate(timeRefFrom, "yyyy-MM-dd HH:mm:ss.S").getTime
            endTime =   timeRefTo.getTime;///DateUtil.parseDate(timeRefTo, "yyyy-MM-dd HH:mm:ss.S").getTime
          }


        }

      data += SLAPeriod(pk,slaType, clientIdRef, clientNameRef,slaTimeRef, startTime,endTime,fileTypeRef, timePeriod, redAlert, greenAlert, yellowAlert, slaOldValue, slaName, description)
    }
    if(connection!=null)
      connection.close()
    return data;
  }

  def findAlertInfo(slaName:String) :ArrayBuffer[AlertInfo] = {
    println("********** Find Alert **************")
    println("********** "+slaName+ " **************")
    var  connection:Connection = getConnection();
    //if(alertInfo==null){
      alertInfo = connection.prepareStatement("SELECT * FROM PETPE_ALERT WHERE KPI_NAME=?")
    //}
    alertInfo.setString(1, slaName)
    var alertDetail:ArrayBuffer[AlertInfo] = ArrayBuffer[AlertInfo]();
    val resultSet:ResultSet = alertInfo.executeQuery();
    if(resultSet.next()){
      val alertName:String  = resultSet.getString("ALERT_NAME");
      val condition:String  = resultSet.getString("CONDITION");
      val description:String  = resultSet.getString("DESCRIPTION");
      val priority:String  = resultSet.getString("PRIORITY");
      val period:String  = resultSet.getString("TIME_PERIOD");
      val notificationFreqency:String  = resultSet.getString("NOTIFI_FR");
      val notificationStart:Timestamp  = resultSet.getTimestamp("NOTIF_START_DT");
      alertDetail += AlertInfo(alertName, condition, description, priority, period, notificationFreqency, new Date(notificationStart.getTime))
    }
    resultSet.close()
    connection.close()
    return alertDetail;
  }
  def findClientInfo(client:String) : ClientInfo = {
    var  connection:Connection = getConnection();
    //SELECT  TP_NAME, CLIENT_ID, SUCCESS_PERCENTAGE FROM PETPE_TRADINGPARTNER_FG WHERE TP_NAME='ptagma1'
   // if(psmt==null){
      psmt = connection.prepareStatement("SELECT  TP_NAME, CLIENT_ID, SUCCESS_PERCENTAGE FROM PETPE_TRADINGPARTNER_FG WHERE TP_NAME=?")
    //}
    psmt.setString(1, client)
    var clientInfo :ClientInfo = null;
    val resultSet:ResultSet = psmt.executeQuery()
    if(resultSet.next()){
    //  println(resultSet.getString(1))
     // println(resultSet.getString(2))
     // println(resultSet.getString(3))
      clientInfo = ClientInfo(resultSet.getString(1), resultSet.getString(2), resultSet.getString(3))
    }
    if(connection!=null)
      connection.close();
    return clientInfo;
  }

  def updateClientSLA(slaAvg:Double, sla:SLAPeriod) : Unit = {
    var  connection:Connection = getConnection();
   // if(updatePsmt==null){
      updatePsmt = connection.prepareStatement("UPDATE  PETPE_SLA SET SLA_VALUE=?, TIME_REF_FROM=?, TIME_REF_TO=?, SLA_OLD_VALUE=? WHERE CLIENT_ID_REF=? and PK_ID=?")
   // }
  //  println(DateUtil.parseDate(sla.timeRefFrom, "yyyy-MM-dd HH:mm:ss.S"))
  //  println(DateUtil.parseDate(sla.timeRefTo, "yyyy-MM-dd HH:mm:ss.S"))
    if(sla.slaType!=null && sla.slaType.equalsIgnoreCase("D"))
      updatePsmt.setString(1, (slaAvg.toLong) +"")
    else
      updatePsmt.setString(1, slaAvg+"")
      
    updatePsmt.setDate(2, new java.sql.Date(DateUtil.parseDate(sla.timeRefFrom, "yyyy-MM-dd HH:mm:ss.S").getTime))
    updatePsmt.setDate(3, new java.sql.Date(DateUtil.parseDate(sla.timeRefTo, "yyyy-MM-dd HH:mm:ss.S").getTime))
    updatePsmt.setString(4,sla.slaOldValue)
    updatePsmt.setString(5,sla.clientIdRef)
    updatePsmt.setString(6,sla.pk)

    val updateCount:Int = updatePsmt.executeUpdate();
    // Add alter svaed.
    val alertInfo:ArrayBuffer[AlertInfo] = findAlertInfo(sla.slaName)
    if(alertInfo!=null) {
      alertInfo.foreach(alert=> {
        generateAlert(alert, sla, slaAvg);
      })
    }

    if(connection!=null)
      connection.close();
  }


  def generateAlert(alertInfo:AlertInfo, sla:SLAPeriod, slaAvg:Double)  = {

    /*if(sla.greenAlert!=null && sla.greenAlert.enable && slaAvg >=sla.greenAlert.startRange && slaAvg <=sla.greenAlert.endRange){
      insertAlert(alertInfo, sla, Alert(UniqueIdentifier.generate(8), "Green Alert", slaAvg, sla.clientIdRef, sla.clientName))
    } else  if(sla.yellowAlert!=null && sla.yellowAlert.enable && slaAvg >=sla.yellowAlert.startRange && slaAvg <= sla.yellowAlert.endRange){
      insertAlert(alertInfo, sla,Alert(UniqueIdentifier.generate(8), "Yellow Alert", slaAvg, sla.clientIdRef, sla.clientName))

    } else if(sla.redAlert!=null && sla.redAlert.enable && slaAvg >=sla.redAlert.startRange && slaAvg <= sla.redAlert.endRange){
      insertAlert(alertInfo, sla,Alert(UniqueIdentifier.generate(8), "Red Alert", slaAvg, sla.clientIdRef, sla.clientName))
    }
*/
    println("....**********......" + alertInfo)
  //
    if(alertInfo!=null) {

      println("....********** :" +alertInfo.condition+":....********** :")
    alertInfo.condition match {
      case "Above Yellow" => {

        if(sla.yellowAlert!=null && sla.yellowAlert.enable && slaAvg >=sla.yellowAlert.startRange && slaAvg <=sla.yellowAlert.endRange){
          var result:Int = com.Common.compareDate(alertInfo.notificationStartDt, new java.util.Date());
          if(result<=0){
            insertAlert(alertInfo, sla,Alert(UniqueIdentifier.generate(8), "Above Yellow Alert", slaAvg, sla.clientIdRef, sla.clientName))
          }

        }
      }
      case "Below Yellow" => {

        if(sla.redAlert!=null && sla.redAlert.enable && slaAvg <= sla.yellowAlert.startRange){
          var result:Int = com.Common.compareDate(alertInfo.notificationStartDt, new java.util.Date());
          if(result==0 || result == -1) {
            insertAlert(alertInfo, sla, Alert(UniqueIdentifier.generate(8), "Below Yellow Alert", slaAvg, sla.clientIdRef, sla.clientName))
          }
        }
      }
      case "Below Green" => {
        println("....**********Below Green......")
        if(sla.greenAlert!=null && sla.greenAlert.enable && slaAvg <=sla.greenAlert.startRange){
          var result:Int = com.Common.compareDate(alertInfo.notificationStartDt, new java.util.Date());
          if(result<=0) {
            insertAlert(alertInfo, sla, Alert(UniqueIdentifier.generate(8), "Below Green", slaAvg, sla.clientIdRef, sla.clientName))
          }
        }
      }
      case "Below Red" => {
        println("....**********Below Below......")
        if(sla.redAlert!=null && sla.redAlert.enable && slaAvg >=sla.redAlert.startRange && slaAvg <= sla.redAlert.endRange){
          insertAlert(alertInfo, sla,Alert(UniqueIdentifier.generate(8), "Below Red", slaAvg, sla.clientIdRef, sla.clientName))
        }
      }
      case _ => {

      }
    } }

  }
  def insertAlert(alertInfo: AlertInfo, sla:SLAPeriod, alert:Alert) : Unit = {
    var  connection:Connection = getConnection();
  //  if(alertInsert==null){
      alertInsert = connection.prepareStatement("INSERT INTO PETPE_ALL_ALERTS (PK_ID, ALERT_NAME, DESCRIPTION, SLA_NAME, PRIORITY, CONDITION, " +
        "PERIOD, CLIENT_NAME, CLIENT_ID, ALERT_VALUE, TIMESTAMP) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")
   // }


    alertInsert.setString(1, alert.pk) //PK
    alertInsert.setString(2, alertInfo.alertName) //PK
    alertInsert.setString(3, alertInfo.description) //PK
    alertInsert.setString(4, sla.slaName) //PK
    alertInsert.setString(5, alertInfo.priority) //PK
    alertInsert.setString(6, alertInfo.condition) //PK
    alertInsert.setString(7, alertInfo.period) //PK
    alertInsert.setString(8, alert.clientName) //PK
    alertInsert.setString(9, alert.clientId) //PK
    alertInsert.setString(10, alert.value+"") //PK
    alertInsert.setTimestamp(11, new Timestamp(new java.util.Date().getTime)) //PK
    alertInsert.execute()
    if(connection!=null)
      connection.close()
      try {
        var mail = new EmailUtil.Mail(
          from = "vijay.reddy@pragmaedge.com",
          to = Seq("harinath.chalamala@pragmaedge.com","vijay.reddy@pragmaedge.com"),
          subject = "Alert Information",
          message = "Alert Details:\nAlert Name: "+ alertInfo.alertName +"\nAlert Description: "+ alertInfo.description +"\nSLA Name: "+sla.slaName)
        EmailUtil.sendMail(mail)
      } catch {
        case e: Exception => e.printStackTrace()
      }
  }
    
  
}


