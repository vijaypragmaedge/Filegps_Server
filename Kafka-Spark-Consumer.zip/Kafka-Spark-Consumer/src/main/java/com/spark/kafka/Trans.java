package com.spark.kafka;

import org.apache.avro.specific.SpecificData;

@SuppressWarnings("all")
@org.apache.avro.specific.AvroGenerated
public class Trans extends org.apache.avro.specific.SpecificRecordBase implements org.apache.avro.specific.SpecificRecord {
  private static final long serialVersionUID = -3207041126002928339L;
  public static final org.apache.avro.Schema SCHEMA$ = new org.apache.avro.Schema.Parser().parse("{\"type\":\"record\",\"name\":\"TestTrans\",\"namespace\":\"com.my.kafka.com.my.kafka\",\"fields\":[{\"name\":\"AcctNbr\",\"type\":\"string\"},{\"name\":\"TransID\",\"type\":\"string\"},{\"name\":\"CurrencyCd\",\"type\":\"int\"},{\"name\":\"TransAmt\",\"type\":\"int\"},{\"name\":\"TransStatus\",\"type\":\"string\"},{\"name\":\"TranspostDt\",\"type\":\"long\"},{\"name\":\"LoadTime\",\"type\":\"long\"},{\"name\":\"SrcTxtName\",\"type\":\"string\"},{\"name\":\"TransType\",\"type\":\"string\"},{\"name\":\"BatchId\",\"type\":\"long\"},{\"name\":\"EffectiveDt\",\"type\":\"long\"},{\"name\":\"ExpiredDt\",\"type\":\"long\"},{\"name\":\"SrceSystemId\",\"type\":\"int\"}]}");
  public static org.apache.avro.Schema getClassSchema() { return SCHEMA$; }
  @Deprecated public java.lang.CharSequence AcctNbr;
  @Deprecated public java.lang.CharSequence TransID;
  @Deprecated public int CurrencyCd;
  @Deprecated public int TransAmt;
  @Deprecated public java.lang.CharSequence TransStatus;
  @Deprecated public long TranspostDt;
  @Deprecated public long LoadTime;
  @Deprecated public java.lang.CharSequence SrcTxtName;
  @Deprecated public java.lang.CharSequence TransType;
  @Deprecated public long BatchId;
  @Deprecated public long EffectiveDt;
  @Deprecated public long ExpiredDt;
  @Deprecated public int SrceSystemId;

  /**
   * Default constructor.  Note that this does not initialize fields
   * to their default values from the schema.  If that is desired then
   * one should use <code>newBuilder()</code>.
   */
  public Trans() {}

  /**
   * All-args constructor.
   * @param AcctNbr The new value for AcctNbr
   * @param TransID The new value for TransID
   * @param CurrencyCd The new value for CurrencyCd
   * @param TransAmt The new value for TransAmt
   * @param TransStatus The new value for TransStatus
   * @param TranspostDt The new value for TranspostDt
   * @param LoadTime The new value for LoadTime
   * @param SrcTxtName The new value for SrcTxtName
   * @param TransType The new value for TransType
   * @param BatchId The new value for BatchId
   * @param EffectiveDt The new value for EffectiveDt
   * @param ExpiredDt The new value for ExpiredDt
   * @param SrceSystemId The new value for SrceSystemId
   */
  public Trans(java.lang.CharSequence AcctNbr, java.lang.CharSequence TransID, java.lang.Integer CurrencyCd, java.lang.Integer TransAmt, java.lang.CharSequence TransStatus, java.lang.Long TranspostDt, java.lang.Long LoadTime, java.lang.CharSequence SrcTxtName, java.lang.CharSequence TransType, java.lang.Long BatchId, java.lang.Long EffectiveDt, java.lang.Long ExpiredDt, java.lang.Integer SrceSystemId) {
    this.AcctNbr = AcctNbr;
    this.TransID = TransID;
    this.CurrencyCd = CurrencyCd;
    this.TransAmt = TransAmt;
    this.TransStatus = TransStatus;
    this.TranspostDt = TranspostDt;
    this.LoadTime = LoadTime;
    this.SrcTxtName = SrcTxtName;
    this.TransType = TransType;
    this.BatchId = BatchId;
    this.EffectiveDt = EffectiveDt;
    this.ExpiredDt = ExpiredDt;
    this.SrceSystemId = SrceSystemId;
  }

  public org.apache.avro.Schema getSchema() { return SCHEMA$; }
  // Used by DatumWriter.  Applications should not call.
  public java.lang.Object get(int field$) {
    switch (field$) {
    case 0: return AcctNbr;
    case 1: return TransID;
    case 2: return CurrencyCd;
    case 3: return TransAmt;
    case 4: return TransStatus;
    case 5: return TranspostDt;
    case 6: return LoadTime;
    case 7: return SrcTxtName;
    case 8: return TransType;
    case 9: return BatchId;
    case 10: return EffectiveDt;
    case 11: return ExpiredDt;
    case 12: return SrceSystemId;
    default: throw new org.apache.avro.AvroRuntimeException("Bad index");
    }
  }

  // Used by DatumReader.  Applications should not call.
  @SuppressWarnings(value="unchecked")
  public void put(int field$, java.lang.Object value$) {
    switch (field$) {
    case 0: AcctNbr = (java.lang.CharSequence)value$; break;
    case 1: TransID = (java.lang.CharSequence)value$; break;
    case 2: CurrencyCd = (java.lang.Integer)value$; break;
    case 3: TransAmt = (java.lang.Integer)value$; break;
    case 4: TransStatus = (java.lang.CharSequence)value$; break;
    case 5: TranspostDt = (java.lang.Long)value$; break;
    case 6: LoadTime = (java.lang.Long)value$; break;
    case 7: SrcTxtName = (java.lang.CharSequence)value$; break;
    case 8: TransType = (java.lang.CharSequence)value$; break;
    case 9: BatchId = (java.lang.Long)value$; break;
    case 10: EffectiveDt = (java.lang.Long)value$; break;
    case 11: ExpiredDt = (java.lang.Long)value$; break;
    case 12: SrceSystemId = (java.lang.Integer)value$; break;
    default: throw new org.apache.avro.AvroRuntimeException("Bad index");
    }
  }

  /**
   * Gets the value of the 'AcctNbr' field.
   * @return The value of the 'AcctNbr' field.
   */
  public java.lang.CharSequence getAcctNbr() {
    return AcctNbr;
  }

  /**
   * Sets the value of the 'AcctNbr' field.
   * @param value the value to set.
   */
  public void setAcctNbr(java.lang.CharSequence value) {
    this.AcctNbr = value;
  }

  /**
   * Gets the value of the 'TransID' field.
   * @return The value of the 'TransID' field.
   */
  public java.lang.CharSequence getTransID() {
    return TransID;
  }

  /**
   * Sets the value of the 'TransID' field.
   * @param value the value to set.
   */
  public void setTransID(java.lang.CharSequence value) {
    this.TransID = value;
  }

  /**
   * Gets the value of the 'CurrencyCd' field.
   * @return The value of the 'CurrencyCd' field.
   */
  public java.lang.Integer getCurrencyCd() {
    return CurrencyCd;
  }

  /**
   * Sets the value of the 'CurrencyCd' field.
   * @param value the value to set.
   */
  public void setCurrencyCd(java.lang.Integer value) {
    this.CurrencyCd = value;
  }

  /**
   * Gets the value of the 'TransAmt' field.
   * @return The value of the 'TransAmt' field.
   */
  public java.lang.Integer getTransAmt() {
    return TransAmt;
  }

  /**
   * Sets the value of the 'TransAmt' field.
   * @param value the value to set.
   */
  public void setTransAmt(java.lang.Integer value) {
    this.TransAmt = value;
  }

  /**
   * Gets the value of the 'TransStatus' field.
   * @return The value of the 'TransStatus' field.
   */
  public java.lang.CharSequence getTransStatus() {
    return TransStatus;
  }

  /**
   * Sets the value of the 'TransStatus' field.
   * @param value the value to set.
   */
  public void setTransStatus(java.lang.CharSequence value) {
    this.TransStatus = value;
  }

  /**
   * Gets the value of the 'TranspostDt' field.
   * @return The value of the 'TranspostDt' field.
   */
  public java.lang.Long getTranspostDt() {
    return TranspostDt;
  }

  /**
   * Sets the value of the 'TranspostDt' field.
   * @param value the value to set.
   */
  public void setTranspostDt(java.lang.Long value) {
    this.TranspostDt = value;
  }

  /**
   * Gets the value of the 'LoadTime' field.
   * @return The value of the 'LoadTime' field.
   */
  public java.lang.Long getLoadTime() {
    return LoadTime;
  }

  /**
   * Sets the value of the 'LoadTime' field.
   * @param value the value to set.
   */
  public void setLoadTime(java.lang.Long value) {
    this.LoadTime = value;
  }

  /**
   * Gets the value of the 'SrcTxtName' field.
   * @return The value of the 'SrcTxtName' field.
   */
  public java.lang.CharSequence getSrcTxtName() {
    return SrcTxtName;
  }

  /**
   * Sets the value of the 'SrcTxtName' field.
   * @param value the value to set.
   */
  public void setSrcTxtName(java.lang.CharSequence value) {
    this.SrcTxtName = value;
  }

  /**
   * Gets the value of the 'TransType' field.
   * @return The value of the 'TransType' field.
   */
  public java.lang.CharSequence getTransType() {
    return TransType;
  }

  /**
   * Sets the value of the 'TransType' field.
   * @param value the value to set.
   */
  public void setTransType(java.lang.CharSequence value) {
    this.TransType = value;
  }

  /**
   * Gets the value of the 'BatchId' field.
   * @return The value of the 'BatchId' field.
   */
  public java.lang.Long getBatchId() {
    return BatchId;
  }

  /**
   * Sets the value of the 'BatchId' field.
   * @param value the value to set.
   */
  public void setBatchId(java.lang.Long value) {
    this.BatchId = value;
  }

  /**
   * Gets the value of the 'EffectiveDt' field.
   * @return The value of the 'EffectiveDt' field.
   */
  public java.lang.Long getEffectiveDt() {
    return EffectiveDt;
  }

  /**
   * Sets the value of the 'EffectiveDt' field.
   * @param value the value to set.
   */
  public void setEffectiveDt(java.lang.Long value) {
    this.EffectiveDt = value;
  }

  /**
   * Gets the value of the 'ExpiredDt' field.
   * @return The value of the 'ExpiredDt' field.
   */
  public java.lang.Long getExpiredDt() {
    return ExpiredDt;
  }

  /**
   * Sets the value of the 'ExpiredDt' field.
   * @param value the value to set.
   */
  public void setExpiredDt(java.lang.Long value) {
    this.ExpiredDt = value;
  }

  /**
   * Gets the value of the 'SrceSystemId' field.
   * @return The value of the 'SrceSystemId' field.
   */
  public java.lang.Integer getSrceSystemId() {
    return SrceSystemId;
  }

  /**
   * Sets the value of the 'SrceSystemId' field.
   * @param value the value to set.
   */
  public void setSrceSystemId(java.lang.Integer value) {
    this.SrceSystemId = value;
  }

  /**
   * Creates a new TestTrans RecordBuilder.
   * @return A new TestTrans RecordBuilder
   */
  public static Trans.Builder newBuilder() {
    return new Trans.Builder();
  }

  /**
   * Creates a new TestTrans RecordBuilder by copying an existing Builder.
   * @param other The existing builder to copy.
   * @return A new TestTrans RecordBuilder
   */
  public static Trans.Builder newBuilder(Trans.Builder other) {
    return new Trans.Builder(other);
  }

  /**
   * Creates a new TestTrans RecordBuilder by copying an existing TestTrans instance.
   * @param other The existing instance to copy.
   * @return A new TestTrans RecordBuilder
   */
  public static Trans.Builder newBuilder(Trans other) {
    return new Trans.Builder(other);
  }

  /**
   * RecordBuilder for TestTrans instances.
   */
  public static class Builder extends org.apache.avro.specific.SpecificRecordBuilderBase<Trans>
    implements org.apache.avro.data.RecordBuilder<Trans> {

    private java.lang.CharSequence AcctNbr;
    private java.lang.CharSequence TransID;
    private int CurrencyCd;
    private int TransAmt;
    private java.lang.CharSequence TransStatus;
    private long TranspostDt;
    private long LoadTime;
    private java.lang.CharSequence SrcTxtName;
    private java.lang.CharSequence TransType;
    private long BatchId;
    private long EffectiveDt;
    private long ExpiredDt;
    private int SrceSystemId;

    /** Creates a new Builder */
    private Builder() {
      super(SCHEMA$);
    }

    /**
     * Creates a Builder by copying an existing Builder.
     * @param other The existing Builder to copy.
     */
    private Builder(Trans.Builder other) {
      super(other);
      if (isValidValue(fields()[0], other.AcctNbr)) {
        this.AcctNbr = data().deepCopy(fields()[0].schema(), other.AcctNbr);
        fieldSetFlags()[0] = true;
      }
      if (isValidValue(fields()[1], other.TransID)) {
        this.TransID = data().deepCopy(fields()[1].schema(), other.TransID);
        fieldSetFlags()[1] = true;
      }
      if (isValidValue(fields()[2], other.CurrencyCd)) {
        this.CurrencyCd = data().deepCopy(fields()[2].schema(), other.CurrencyCd);
        fieldSetFlags()[2] = true;
      }
      if (isValidValue(fields()[3], other.TransAmt)) {
        this.TransAmt = data().deepCopy(fields()[3].schema(), other.TransAmt);
        fieldSetFlags()[3] = true;
      }
      if (isValidValue(fields()[4], other.TransStatus)) {
        this.TransStatus = data().deepCopy(fields()[4].schema(), other.TransStatus);
        fieldSetFlags()[4] = true;
      }
      if (isValidValue(fields()[5], other.TranspostDt)) {
        this.TranspostDt = data().deepCopy(fields()[5].schema(), other.TranspostDt);
        fieldSetFlags()[5] = true;
      }
      if (isValidValue(fields()[6], other.LoadTime)) {
        this.LoadTime = data().deepCopy(fields()[6].schema(), other.LoadTime);
        fieldSetFlags()[6] = true;
      }
      if (isValidValue(fields()[7], other.SrcTxtName)) {
        this.SrcTxtName = data().deepCopy(fields()[7].schema(), other.SrcTxtName);
        fieldSetFlags()[7] = true;
      }
      if (isValidValue(fields()[8], other.TransType)) {
        this.TransType = data().deepCopy(fields()[8].schema(), other.TransType);
        fieldSetFlags()[8] = true;
      }
      if (isValidValue(fields()[9], other.BatchId)) {
        this.BatchId = data().deepCopy(fields()[9].schema(), other.BatchId);
        fieldSetFlags()[9] = true;
      }
      if (isValidValue(fields()[10], other.EffectiveDt)) {
        this.EffectiveDt = data().deepCopy(fields()[10].schema(), other.EffectiveDt);
        fieldSetFlags()[10] = true;
      }
      if (isValidValue(fields()[11], other.ExpiredDt)) {
        this.ExpiredDt = data().deepCopy(fields()[11].schema(), other.ExpiredDt);
        fieldSetFlags()[11] = true;
      }
      if (isValidValue(fields()[12], other.SrceSystemId)) {
        this.SrceSystemId = data().deepCopy(fields()[12].schema(), other.SrceSystemId);
        fieldSetFlags()[12] = true;
      }
    }

    /**
     * Creates a Builder by copying an existing TestTrans instance
     * @param other The existing instance to copy.
     */
    private Builder(Trans other) {
            super(SCHEMA$);
      if (isValidValue(fields()[0], other.AcctNbr)) {
        this.AcctNbr = data().deepCopy(fields()[0].schema(), other.AcctNbr);
        fieldSetFlags()[0] = true;
      }
      if (isValidValue(fields()[1], other.TransID)) {
        this.TransID = data().deepCopy(fields()[1].schema(), other.TransID);
        fieldSetFlags()[1] = true;
      }
      if (isValidValue(fields()[2], other.CurrencyCd)) {
        this.CurrencyCd = data().deepCopy(fields()[2].schema(), other.CurrencyCd);
        fieldSetFlags()[2] = true;
      }
      if (isValidValue(fields()[3], other.TransAmt)) {
        this.TransAmt = data().deepCopy(fields()[3].schema(), other.TransAmt);
        fieldSetFlags()[3] = true;
      }
      if (isValidValue(fields()[4], other.TransStatus)) {
        this.TransStatus = data().deepCopy(fields()[4].schema(), other.TransStatus);
        fieldSetFlags()[4] = true;
      }
      if (isValidValue(fields()[5], other.TranspostDt)) {
        this.TranspostDt = data().deepCopy(fields()[5].schema(), other.TranspostDt);
        fieldSetFlags()[5] = true;
      }
      if (isValidValue(fields()[6], other.LoadTime)) {
        this.LoadTime = data().deepCopy(fields()[6].schema(), other.LoadTime);
        fieldSetFlags()[6] = true;
      }
      if (isValidValue(fields()[7], other.SrcTxtName)) {
        this.SrcTxtName = data().deepCopy(fields()[7].schema(), other.SrcTxtName);
        fieldSetFlags()[7] = true;
      }

      if (isValidValue(fields()[8], other.TransType)) {
        this.TransType = data().deepCopy(fields()[8].schema(), other.TransType);
        fieldSetFlags()[8] = true;
      }
      if (isValidValue(fields()[9], other.BatchId)) {
        this.BatchId = data().deepCopy(fields()[9].schema(), other.BatchId);
        fieldSetFlags()[9] = true;
      }
      if (isValidValue(fields()[10], other.EffectiveDt)) {
        this.EffectiveDt = data().deepCopy(fields()[10].schema(), other.EffectiveDt);
        fieldSetFlags()[10] = true;
      }
      if (isValidValue(fields()[11], other.ExpiredDt)) {
        this.ExpiredDt = data().deepCopy(fields()[11].schema(), other.ExpiredDt);
        fieldSetFlags()[11] = true;
      }
      if (isValidValue(fields()[12], other.SrceSystemId)) {
        this.SrceSystemId = data().deepCopy(fields()[12].schema(), other.SrceSystemId);
        fieldSetFlags()[12] = true;
      }
    }

    /**
      * Gets the value of the 'AcctNbr' field.
      * @return The value.
      */
    public java.lang.CharSequence getAcctNbr() {
      return AcctNbr;
    }

    /**
      * Sets the value of the 'AcctNbr' field.
      * @param value The value of 'AcctNbr'.
      * @return This builder.
      */
    public Trans.Builder setAcctNbr(java.lang.CharSequence value) {
      validate(fields()[0], value);
      this.AcctNbr = value;
      fieldSetFlags()[0] = true;
      return this;
    }

    /**
      * Checks whether the 'AcctNbr' field has been set.
      * @return True if the 'AcctNbr' field has been set, false otherwise.
      */
    public boolean hasAcctNbr() {
      return fieldSetFlags()[0];
    }


    /**
      * Clears the value of the 'AcctNbr' field.
      * @return This builder.
      */
    public Trans.Builder clearAcctNbr() {
      AcctNbr = null;
      fieldSetFlags()[0] = false;
      return this;
    }

    /**
      * Gets the value of the 'TransID' field.
      * @return The value.
      */
    public java.lang.CharSequence getTransID() {
      return TransID;
    }

    /**
      * Sets the value of the 'TransID' field.
      * @param value The value of 'TransID'.
      * @return This builder.
      */
    public Trans.Builder setTransID(java.lang.CharSequence value) {
      validate(fields()[1], value);
      this.TransID = value;
      fieldSetFlags()[1] = true;
      return this;
    }

    /**
      * Checks whether the 'TransID' field has been set.
      * @return True if the 'TransID' field has been set, false otherwise.
      */
    public boolean hasTransID() {
      return fieldSetFlags()[1];
    }


    /**
      * Clears the value of the 'TransID' field.
      * @return This builder.
      */
    public Trans.Builder clearTransID() {
      TransID = null;
      fieldSetFlags()[1] = false;
      return this;
    }

    /**
      * Gets the value of the 'CurrencyCd' field.
      * @return The value.
      */
    public java.lang.Integer getCurrencyCd() {
      return CurrencyCd;
    }

    /**
      * Sets the value of the 'CurrencyCd' field.
      * @param value The value of 'CurrencyCd'.
      * @return This builder.
      */
    public Trans.Builder setCurrencyCd(int value) {
      validate(fields()[2], value);
      this.CurrencyCd = value;
      fieldSetFlags()[2] = true;
      return this;
    }

    /**
      * Checks whether the 'CurrencyCd' field has been set.
      * @return True if the 'CurrencyCd' field has been set, false otherwise.
      */
    public boolean hasCurrencyCd() {
      return fieldSetFlags()[2];
    }


    /**
      * Clears the value of the 'CurrencyCd' field.
      * @return This builder.
      */
    public Trans.Builder clearCurrencyCd() {
      fieldSetFlags()[2] = false;
      return this;
    }

    /**
      * Gets the value of the 'TransAmt' field.
      * @return The value.
      */
    public java.lang.Integer getTransAmt() {
      return TransAmt;
    }

    /**
      * Sets the value of the 'TransAmt' field.
      * @param value The value of 'TransAmt'.
      * @return This builder.
      */
    public Trans.Builder setTransAmt(int value) {
      validate(fields()[3], value);
      this.TransAmt = value;
      fieldSetFlags()[3] = true;
      return this;
    }

    /**
      * Checks whether the 'TransAmt' field has been set.
      * @return True if the 'TransAmt' field has been set, false otherwise.
      */
    public boolean hasTransAmt() {
      return fieldSetFlags()[3];
    }


    /**
      * Clears the value of the 'TransAmt' field.
      * @return This builder.
      */
    public Trans.Builder clearTransAmt() {
      fieldSetFlags()[3] = false;
      return this;
    }

    /**
      * Gets the value of the 'TransStatus' field.
      * @return The value.
      */
    public java.lang.CharSequence getTransStatus() {
      return TransStatus;
    }

    /**
      * Sets the value of the 'TransStatus' field.
      * @param value The value of 'TransStatus'.
      * @return This builder.
      */
    public Trans.Builder setTransStatus(java.lang.CharSequence value) {
      validate(fields()[4], value);
      this.TransStatus = value;
      fieldSetFlags()[4] = true;
      return this;
    }

    /**
      * Checks whether the 'TransStatus' field has been set.
      * @return True if the 'TransStatus' field has been set, false otherwise.
      */
    public boolean hasTransStatus() {
      return fieldSetFlags()[4];
    }


    /**
      * Clears the value of the 'TransStatus' field.
      * @return This builder.
      */
    public Trans.Builder clearTransStatus() {
      TransStatus = null;
      fieldSetFlags()[4] = false;
      return this;
    }

    /**
      * Gets the value of the 'TranspostDt' field.
      * @return The value.
      */
    public java.lang.Long getTranspostDt() {
      return TranspostDt;
    }

    /**
      * Sets the value of the 'TranspostDt' field.
      * @param value The value of 'TranspostDt'.
      * @return This builder.
      */
    public Trans.Builder setTranspostDt(long value) {
      validate(fields()[5], value);
      this.TranspostDt = value;
      fieldSetFlags()[5] = true;
      return this;
    }

    /**
      * Checks whether the 'TranspostDt' field has been set.
      * @return True if the 'TranspostDt' field has been set, false otherwise.
      */
    public boolean hasTranspostDt() {
      return fieldSetFlags()[5];
    }


    /**
      * Clears the value of the 'TranspostDt' field.
      * @return This builder.
      */
    public Trans.Builder clearTranspostDt() {
      fieldSetFlags()[5] = false;
      return this;
    }

    /**
      * Gets the value of the 'LoadTime' field.
      * @return The value.
      */
    public java.lang.Long getLoadTime() {
      return LoadTime;
    }

    /**
      * Sets the value of the 'LoadTime' field.
      * @param value The value of 'LoadTime'.
      * @return This builder.
      */
    public Trans.Builder setLoadTime(long value) {
      validate(fields()[6], value);
      this.LoadTime = value;
      fieldSetFlags()[6] = true;
      return this;
    }

    /**
      * Checks whether the 'LoadTime' field has been set.
      * @return True if the 'LoadTime' field has been set, false otherwise.
      */
    public boolean hasLoadTime() {
      return fieldSetFlags()[6];
    }


    /**
      * Clears the value of the 'LoadTime' field.
      * @return This builder.
      */
    public Trans.Builder clearLoadTime() {
      fieldSetFlags()[6] = false;
      return this;
    }

    /**
      * Gets the value of the 'SrcTxtName' field.
      * @return The value.
      */
    public java.lang.CharSequence getSrcTxtName() {
      return SrcTxtName;
    }

    /**
      * Sets the value of the 'SrcTxtName' field.
      * @param value The value of 'SrcTxtName'.
      * @return This builder.
      */
    public Trans.Builder setSrcTxtName(java.lang.CharSequence value) {
      validate(fields()[7], value);
      this.SrcTxtName = value;
      fieldSetFlags()[7] = true;
      return this;
    }

    /**
      * Checks whether the 'SrcTxtName' field has been set.
      * @return True if the 'SrcTxtName' field has been set, false otherwise.
      */
    public boolean hasSrcTxtName() {
      return fieldSetFlags()[7];
    }


    /**
      * Clears the value of the 'SrcTxtName' field.
      * @return This builder.
      */
    public Trans.Builder clearSrcTxtName() {
      SrcTxtName = null;
      fieldSetFlags()[7] = false;
      return this;
    }

    /**
      * Gets the value of the 'TransType' field.
      * @return The value.
      */
    public java.lang.CharSequence getTransType() {
      return TransType;
    }

    /**
      * Sets the value of the 'TransType' field.
      * @param value The value of 'TransType'.
      * @return This builder.
      */
    public Trans.Builder setTransType(java.lang.CharSequence value) {
      validate(fields()[8], value);
      this.TransType = value;
      fieldSetFlags()[8] = true;
      return this;
    }

    /**
      * Checks whether the 'TransType' field has been set.
      * @return True if the 'TransType' field has been set, false otherwise.
      */
    public boolean hasTransType() {
      return fieldSetFlags()[8];
    }


    /**
      * Clears the value of the 'TransType' field.
      * @return This builder.
      */
    public Trans.Builder clearTransType() {
      TransType = null;
      fieldSetFlags()[8] = false;
      return this;
    }

    /**
      * Gets the value of the 'BatchId' field.
      * @return The value.
      */
    public java.lang.Long getBatchId() {
      return BatchId;
    }

    /**
      * Sets the value of the 'BatchId' field.
      * @param value The value of 'BatchId'.
      * @return This builder.
      */
    public Trans.Builder setBatchId(long value) {
      validate(fields()[9], value);
      this.BatchId = value;
      fieldSetFlags()[9] = true;
      return this;
    }

    /**
      * Checks whether the 'BatchId' field has been set.
      * @return True if the 'BatchId' field has been set, false otherwise.
      */
    public boolean hasBatchId() {
      return fieldSetFlags()[9];
    }


    /**
      * Clears the value of the 'BatchId' field.
      * @return This builder.
      */
    public Trans.Builder clearBatchId() {
      fieldSetFlags()[9] = false;
      return this;
    }

    /**
      * Gets the value of the 'EffectiveDt' field.
      * @return The value.
      */
    public java.lang.Long getEffectiveDt() {
      return EffectiveDt;
    }

    /**
      * Sets the value of the 'EffectiveDt' field.
      * @param value The value of 'EffectiveDt'.
      * @return This builder.
      */
    public Trans.Builder setEffectiveDt(long value) {
      validate(fields()[10], value);
      this.EffectiveDt = value;
      fieldSetFlags()[10] = true;
      return this;
    }

    /**
      * Checks whether the 'EffectiveDt' field has been set.
      * @return True if the 'EffectiveDt' field has been set, false otherwise.
      */
    public boolean hasEffectiveDt() {
      return fieldSetFlags()[10];
    }


    /**
      * Clears the value of the 'EffectiveDt' field.
      * @return This builder.
      */
    public Trans.Builder clearEffectiveDt() {
      fieldSetFlags()[10] = false;
      return this;
    }

    /**
      * Gets the value of the 'ExpiredDt' field.
      * @return The value.
      */
    public java.lang.Long getExpiredDt() {
      return ExpiredDt;
    }

    /**
      * Sets the value of the 'ExpiredDt' field.
      * @param value The value of 'ExpiredDt'.
      * @return This builder.
      */
    public Trans.Builder setExpiredDt(long value) {
      validate(fields()[11], value);
      this.ExpiredDt = value;
      fieldSetFlags()[11] = true;
      return this;
    }

    /**
      * Checks whether the 'ExpiredDt' field has been set.
      * @return True if the 'ExpiredDt' field has been set, false otherwise.
      */
    public boolean hasExpiredDt() {
      return fieldSetFlags()[11];
    }


    /**
      * Clears the value of the 'ExpiredDt' field.
      * @return This builder.
      */
    public Trans.Builder clearExpiredDt() {
      fieldSetFlags()[11] = false;
      return this;
    }

    /**
      * Gets the value of the 'SrceSystemId' field.
      * @return The value.
      */
    public java.lang.Integer getSrceSystemId() {
      return SrceSystemId;
    }

    /**
      * Sets the value of the 'SrceSystemId' field.
      * @param value The value of 'SrceSystemId'.
      * @return This builder.
      */
    public Trans.Builder setSrceSystemId(int value) {
      validate(fields()[12], value);
      this.SrceSystemId = value;
      fieldSetFlags()[12] = true;
      return this;
    }

    /**
      * Checks whether the 'SrceSystemId' field has been set.
      * @return True if the 'SrceSystemId' field has been set, false otherwise.
      */
    public boolean hasSrceSystemId() {
      return fieldSetFlags()[12];
    }


    /**
      * Clears the value of the 'SrceSystemId' field.
      * @return This builder.
      */
    public Trans.Builder clearSrceSystemId() {
      fieldSetFlags()[12] = false;
      return this;
    }

    @Override
    public Trans build() {
      try {
        Trans record = new Trans();
        record.AcctNbr = fieldSetFlags()[0] ? this.AcctNbr : (java.lang.CharSequence) defaultValue(fields()[0]);
        record.TransID = fieldSetFlags()[1] ? this.TransID : (java.lang.CharSequence) defaultValue(fields()[1]);
        record.CurrencyCd = fieldSetFlags()[2] ? this.CurrencyCd : (java.lang.Integer) defaultValue(fields()[2]);
        record.TransAmt = fieldSetFlags()[3] ? this.TransAmt : (java.lang.Integer) defaultValue(fields()[3]);
        record.TransStatus = fieldSetFlags()[4] ? this.TransStatus : (java.lang.CharSequence) defaultValue(fields()[4]);
        record.TranspostDt = fieldSetFlags()[5] ? this.TranspostDt : (java.lang.Long) defaultValue(fields()[5]);
        record.LoadTime = fieldSetFlags()[6] ? this.LoadTime : (java.lang.Long) defaultValue(fields()[6]);
        record.SrcTxtName = fieldSetFlags()[7] ? this.SrcTxtName : (java.lang.CharSequence) defaultValue(fields()[7]);
        record.TransType = fieldSetFlags()[8] ? this.TransType : (java.lang.CharSequence) defaultValue(fields()[8]);
        record.BatchId = fieldSetFlags()[9] ? this.BatchId : (java.lang.Long) defaultValue(fields()[9]);
        record.EffectiveDt = fieldSetFlags()[10] ? this.EffectiveDt : (java.lang.Long) defaultValue(fields()[10]);
        record.ExpiredDt = fieldSetFlags()[11] ? this.ExpiredDt : (java.lang.Long) defaultValue(fields()[11]);
        record.SrceSystemId = fieldSetFlags()[12] ? this.SrceSystemId : (java.lang.Integer) defaultValue(fields()[12]);
        return record;
      } catch (Exception e) {
        throw new org.apache.avro.AvroRuntimeException(e);
      }
    }
  }

  private static final org.apache.avro.io.DatumWriter
    WRITER$ = new org.apache.avro.specific.SpecificDatumWriter(SCHEMA$);

  @Override public void writeExternal(java.io.ObjectOutput out)
    throws java.io.IOException {
    WRITER$.write(this, SpecificData.getEncoder(out));
  }

  private static final org.apache.avro.io.DatumReader
    READER$ = new org.apache.avro.specific.SpecificDatumReader(SCHEMA$);

  @Override public void readExternal(java.io.ObjectInput in)
    throws java.io.IOException {
    READER$.read(this, SpecificData.getDecoder(in));
  }

}
