package com.spark.kafka;

/**
 * Created by karamjit on 4/12/17.
 */
import org.apache.phoenix.jdbc.PhoenixDriver;

import java.io.Serializable;
import java.sql.*;
import java.util.Date;


public class PhoenixEventDomain implements Serializable {


    private static final long serialVersionUID = 1L;
    String connectionString = "jdbc:phoenix:localhost";
    Connection con = null;

    PreparedStatement prepSales = null;
    PreparedStatement prepAgg = null;
    PreparedStatement prepExist = null;
    Statement stmt = null;

    public PhoenixEventDomain() {
        createConnection();
    }

    public void createConnection() {
        try {
            Class.forName("org.apache.phoenix.jdbc.PhoenixDriver");
            DriverManager.registerDriver(new PhoenixDriver());
            con = DriverManager.getConnection(connectionString);
            System.out.println("Connected");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void saveOrUpdate(Event row) {
        try {

            /*
            CREATE TABLE IF NOT EXISTS processed_event (event_id UNSIGNED_LONG NOT NULL PRIMARY KEY, msgText VARCHAR,
msgId VARCHAR, msgCode VARCHAR,nodeId_first_part VARCHAR,nodeId_second_part VARCHAR,local_file_name VARCHAR,remote_file_name VARCHAR,
 sent_from VARCHAR,sent_to VARCHAR, co_relation_id UNSIGNED_LONG);

             */
            long coId = -1;
            if(row.msgTxt.equalsIgnoreCase("process")) {
                 coId = isExist(row);
            }
            if(row.msgTxt.equalsIgnoreCase("start")) {
                coId =  Long.parseLong(UniqueIdentifier.generate(10));
            }
            if(coId==-1) {
                coId =  000000000l;
            }
            System.out.println("Inserting..." + coId);
    //    if(row.msgTxt.equalsIgnoreCase("start")) {
            if (prepSales == null) {
                String statement = "UPSERT INTO processed_event VALUES (NEXT VALUE FOR processed_event.EVENT_SEQ, ?, ? , ? , ?, ? , ?, ?, ?, ?, ?)";
                this.prepSales = this.con.prepareStatement(statement);
            }
            prepSales.setString(1, row.msgTxt.toString());
            prepSales.setString(2, row.msgId.toString());
            prepSales.setString(3, row.msgCode);
            String nodes[] = row.nodeId.split("/");
            prepSales.setString(4, nodes[0]);
            prepSales.setString(5, nodes[1]);
            prepSales.setString(6, row.localFileName);
            prepSales.setString(7, row.remoteFileName);
            prepSales.setString(8, row.sentFrom);
            prepSales.setString(9, row.sentTo);
            prepSales.setLong(10, coId);
            prepSales.executeUpdate();
  //      } else {

    //    }

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public long isExist(Event row) {
        long coId = -1;

        String nodes[] = row.nodeId.split("/");
        try {
            if (prepExist == null) {
                String statement = "select co_relation_id from processed_event where NODEID_SECOND_PART=? ";
                this.prepExist = this.con.prepareStatement(statement);
            }
            stmt = con.createStatement();

            System.out.println("select co_relation_id from processed_event where NODEID_SECOND_PART='"+nodes[0] +"'");
       //     prepExist.setString(1, "'"+row.localFileName+"'");
          //  prepExist.setString(1, nodes[0]);
            ResultSet result = stmt.executeQuery("select co_relation_id from processed_event where NODEID_SECOND_PART='"+nodes[0]+"'");
            while(result.next()){
                System.out.println("************************");
                coId  = result.getLong("co_relation_id");
                break;
            }
            result.close();
        } catch(Exception e){
            e.printStackTrace();
        }

        return coId;
    }


    public synchronized void closeCon() {
        try {
            if (con != null)
                con.commit();
            con.close();
            if (prepSales != null)
                prepSales.close();
            if (prepAgg != null)
                prepAgg.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

  
    
}
