package com.spark.kafka;

import java.util.Random;

/**
 * Created by karamjit on 4/6/17.
 */
public class UniqueIdentifier {
    public static String generate(int len) {
        String numbers = "0123456789";
        Random random = new Random();
        char[] otp = new char[len];
        for (int i = 0; i < len; i++) {
            otp[i] = numbers.charAt(random.nextInt(numbers.length()));
        }
        return new String(otp);
    }



}
