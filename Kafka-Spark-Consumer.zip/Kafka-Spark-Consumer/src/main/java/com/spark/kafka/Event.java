package com.spark.kafka;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.io.ImmutableBytesWritable;
import org.apache.hadoop.hbase.util.Bytes;

import java.io.Serializable;
import java.lang.reflect.Type;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;

public class Event implements Serializable{
    public String direction;
    public String event;
    public String msgId;
    public String msgTxt;
    public String msgCode;
    public String nodeId;
    public String occurred;
    public String processId;
    public String processName;
    public String stepName;
    public String localFileName;
    public String localPath;
    public String remoteFileName;
    public String protocol;
    public String sentFrom;
    public String sentTo;
    public String clientName;
    public Long timeStamp;
    public String clientId;

    private Map<String, Object> map;
    public Event() {

    }
    public Event(Map<String, Object> map){
        this.map = map;
    }
    public Event(String direction, String event, String msgId, String msgTxt, String msgCode, String nodeId, String occurred,
                 String processId, String processName, String stepName, String localFileName, String localPath, String remoteFileName,
                 String protocol, String sentFrom, String sentTo, String clientName, Long timeStamp, String clientId) {
        this.direction = direction;
        this.event = event;
        this.msgId = msgId;
        this.msgTxt = msgTxt;
        this.msgCode = msgCode;
        this.nodeId = nodeId;
        this.occurred = occurred;
        this.processId = processId;
        this.processName = processName;
        this.stepName = stepName;
        this.localFileName = localFileName;
        this.localPath = localPath;
        this.remoteFileName = remoteFileName;
        this.protocol = protocol;
        this.sentFrom = sentFrom;
        this.sentTo = sentTo;
        this.clientName = clientName;
        this.timeStamp = timeStamp;
        this.clientId = clientId;
    }

    public String toString(){
            Gson json = new Gson();
        return  json.toJson(map);

    }

    public static Event parse(String json) {
        Gson gson = new Gson();
        Event e = new Event();
       // Type stringStringMap = new TypeToken<Map<String, Object>>(){}.getType();
        e.initMap((Map<String, Object>)gson.fromJson(json, Map.class));

        return e;
    }
    boolean isInteger(double d){
        if(d > Long.MAX_VALUE || d < Long.MIN_VALUE){
            return true;
        } else if((long)d == d){
            return true;
        } else {
            return false;
        }
    }
    private  void initMap(Map<String, Object> events) {
        map = events;
        //2016-02-15T18:07:52.971+0000
        //"yyyy-MM-dd'T'HH:mm:ss.SSSZ"	2001-07-04'T'12:08:56.235-0700
        if(map.containsKey("occurred")) {
            map.put("timestamp", parseDate(map.get("occurred").toString(), "yyyy-MM-dd'T'HH:mm:ss.SSSZ").getTime());
        }

    }
    public Date parseDate(String date, String pattern)  {
        SimpleDateFormat formatter = new SimpleDateFormat(pattern);
        try {
            return formatter.parse(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }
    public Map<String, Object> getMap() {
        return  map;
    }


    public static  void main(String args[]) {
        Event e  = parse("{ \"time\":1508531328050,  \"direction\":\"inbound\",\"event\":\"ProcStart\",\"msgId\":\"EVTEX0008D\",\"msgTxt\":\"Start\",\"msgCode\":\"WFN\",\"nodeId\":\"ST/SEN\",\"occurred\":\"2016-02-15T18:07:52.971+0000\",\"processId\":\"1d8b8f73-d609-4cd1-b1be-4e7213b3401e\",\"processName\":\"File Transfer\",\"stepName\":\"DEV.CDSA\",\"localFileName\":\"60231614b5a2de919node1\",\"localPath\":\"file-145555967228.txt\",\"protocol\":\"ile-1455559672258.txt\",\"sentFrom\":\"FTP\",\"sentTo\":\"SEN\",\"clientName\":\"Aetna\"}\n");
        System.out.println("e "+e.convertMapToPut());
    }
    public  Put convertMapToPut() {
    	System.out.println("entered into convertmaptoput method");
        if(map!=null) {
            String nodes[] = map.get("nodeId").toString().split("/");

            Put put = new Put(Bytes.toBytes(nodes[1]+ "_"+ map.get("remoteFileName")));
            if (map.get("msgTxt").toString().equalsIgnoreCase("Start")) {
                if(map.get("localFileName").toString().indexOf(".zip")>0){
                    put = new Put(Bytes.toBytes(nodes[1]+ "_"+ map.get("remoteFileName1")));
                }
            }
            Iterator<Map.Entry<String, Object>> it = map.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<String, Object> entry = it.next();
                System.out.println(" Key : " + entry.getKey());
                System.out.println(" Key : " + entry.getValue().getClass());
                System.out.println(" Key : " + entry.getValue());
                if (entry.getValue() instanceof String) {
                    System.out.println(entry.getValue().toString() + " Key : value : String " + entry.getKey() + "  : " + entry.getValue());
                    put.add(cfDataBytes, Bytes.toBytes(entry.getKey()), Bytes.toBytes(entry.getValue().toString()));
                } else if(entry.getValue() instanceof  Double) {
                    Double d = (Double)entry.getValue();
                    if(isInteger(d)) {
                        System.out.println(" Key is long: " +  d.longValue());
                        put.add(cfDataBytes,  Bytes.toBytes(entry.getKey()), Bytes.toBytes(d.longValue()));
                    } else
                        put.add(cfDataBytes,  Bytes.toBytes(entry.getKey()), Bytes.toBytes(d));

                }
                else if(entry.getValue() instanceof  Long) {
                    Long d = (Long)entry.getValue();
                    System.out.println(d + " Key : value : long " + entry.getKey() + "  : " + entry.getValue());
                    put.add(cfDataBytes,  Bytes.toBytes(entry.getKey()), Bytes.toBytes(d));

                } else if(entry.getValue() instanceof  Integer) {

                    Integer d = (Integer) entry.getValue();
                    System.out.println(d + " Key : value : Interger " + entry.getKey() + "  : " + entry.getValue());

                    put.add(cfDataBytes,  Bytes.toBytes(entry.getKey()), Bytes.toBytes(d));

                }else if(entry.getValue() instanceof  Float) {
                    Float d = (Float)entry.getValue();
                    put.add(cfDataBytes,  Bytes.toBytes(entry.getKey()), Bytes.toBytes(d));

                } else {
                    System.out.println(" Key : value " + entry.getKey() + "  : " + entry.getValue());
                    put.add(cfDataBytes,  Bytes.toBytes(entry.getKey()), Bytes.toBytes(entry.getValue().toString()));
                }
            }
            if (map.get("msgTxt").toString().equalsIgnoreCase("start")) {
                put.add(cfDataBytes, corelationId, Bytes.toBytes(UniqueIdentifier.generate(10)));
            } else {
                put.add(cfDataBytes, corelationId, Bytes.toBytes("EMPTY"));
            }
            put.addColumn(cfDataBytes, successValue, Bytes.toBytes(100+""));
            return put;
        }

        return null;

    }

    public  Put convert1toM(String remoteFilePattern, Put put) {
        if(map!=null) {

            Iterator<Map.Entry<String, Object>> it = map.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<String, Object> entry = it.next();
                System.out.println(" Key : " + entry.getKey());
                System.out.println(" Key : " + entry.getValue().getClass());
                System.out.println(" Key : " + entry.getValue());
                if(entry.getKey().toString().startsWith(remoteFilePattern)) {
                    continue;
                }
                if (entry.getValue() instanceof String) {
                    System.out.println(entry.getValue().toString() + " Key : value : String " + entry.getKey() + "  : " + entry.getValue());
                    put.add(cfDataBytes, Bytes.toBytes(entry.getKey()), Bytes.toBytes(entry.getValue().toString()));
                } else if(entry.getValue() instanceof  Double) {
                    Double d = (Double)entry.getValue();
                    if(isInteger(d)) {
                        //    System.out.println(" Key is long: " +  d.longValue());
                        put.add(cfDataBytes,  Bytes.toBytes(entry.getKey()), Bytes.toBytes(d.longValue()));
                    } else
                        put.add(cfDataBytes,  Bytes.toBytes(entry.getKey()), Bytes.toBytes(d));

                }
                else if(entry.getValue() instanceof  Long) {
                    Long d = (Long)entry.getValue();
                    //   System.out.println(d + " Key : value : long " + entry.getKey() + "  : " + entry.getValue());
                    put.add(cfDataBytes,  Bytes.toBytes(entry.getKey()), Bytes.toBytes(d));

                } else if(entry.getValue() instanceof  Integer) {

                    Integer d = (Integer) entry.getValue();
                    //  System.out.println(d + " Key : value : Interger " + entry.getKey() + "  : " + entry.getValue());

                    put.add(cfDataBytes,  Bytes.toBytes(entry.getKey()), Bytes.toBytes(d));

                }else if(entry.getValue() instanceof  Float) {
                    Float d = (Float)entry.getValue();
                    put.add(cfDataBytes,  Bytes.toBytes(entry.getKey()), Bytes.toBytes(d));

                } else {
                    //   System.out.println(" Key : value " + entry.getKey() + "  : " + entry.getValue());
                    put.add(cfDataBytes,  Bytes.toBytes(entry.getKey()), Bytes.toBytes(entry.getValue().toString()));
                }
            }
            if (map.get("msgTxt").toString().equalsIgnoreCase("start")) {
                put.add(cfDataBytes, corelationId, Bytes.toBytes(UniqueIdentifier.generate(10)));
            } else {
                put.add(cfDataBytes, corelationId, Bytes.toBytes("EMPTY"));
            }
            put.addColumn(cfDataBytes, successValue, Bytes.toBytes(100+""));
            return put;
        }

        return null;

    }
    /*public  Put convertToPut1() {
        try {
           // if(event.equalsIgnoreCase(""))
            String nodes[] = nodeId.split("/");
            System.out.println("Saving with row key : "+ msgTxt);
            System.out.printf("\t%s = %s\n", nodes[1]+ "_"+ remoteFileName, "");

            Put put = new Put(Bytes.toBytes(nodes[1]+ "_"+ remoteFileName));
            put.add(cfDataBytes, directionBytes, Bytes.toBytes(direction));
            put.add(cfDataBytes, eventBytes, Bytes.toBytes(event));
            put.add(cfDataBytes, msgIdBytes, Bytes.toBytes(msgId));
            put.add(cfDataBytes, msgTxtBytes, Bytes.toBytes(msgTxt));
            put.add(cfDataBytes, msgCodeBytes, Bytes.toBytes(msgCode));
            put.add(cfDataBytes, nodeIdBytes, Bytes.toBytes(nodeId));
            put.add(cfDataBytes, occurredBytes, Bytes.toBytes(occurred));
            put.add(cfDataBytes, processIdBytes, Bytes.toBytes(processId));
            put.add(cfDataBytes, processNameBytes, Bytes.toBytes(processName));
            put.add(cfDataBytes, stepNameBytes, Bytes.toBytes(stepName));
            put.add(cfDataBytes, localFileNameBytes, Bytes.toBytes(localFileName));
            put.add(cfDataBytes, localPathBytes, Bytes.toBytes(localPath));
            put.add(cfDataBytes, remoteFileNameBytes, Bytes.toBytes(remoteFileName));
            put.add(cfDataBytes, sentFromBytes, Bytes.toBytes(sentFrom));
            put.add(cfDataBytes, sentToBytes, Bytes.toBytes(sentTo));
            put.add(cfDataBytes, clientNameBytes, Bytes.toBytes(clientName));
            put.add(cfDataBytes, timeStampBytes, Bytes.toBytes(timeStamp));
            put.add(cfDataBytes, clientIdBytes, Bytes.toBytes(clientId));

            if (msgTxt.equalsIgnoreCase("start")) {
                put.add(cfDataBytes, corelationId, Bytes.toBytes(UniqueIdentifier.generate(10)));
            } else {
                put.add(cfDataBytes, corelationId, Bytes.toBytes("EMPTY"));
            }

            return put;
        } catch(Exception e){
            e.printStackTrace();
            System.out.println(e);
        }

        return null;
    }*/


    final public   String tableName = "DATA_EVENT";
    final public  byte[] cfDataBytes = Bytes.toBytes("event");
    final public  byte[] directionBytes = Bytes.toBytes("direction");
    final public  byte[] eventBytes = Bytes.toBytes("event");
    final public  byte[] msgIdBytes = Bytes.toBytes("msgId");
    final public  byte[] msgTxtBytes = Bytes.toBytes("msgTxt");
    final public  byte[] msgCodeBytes = Bytes.toBytes("msgCode");
    final public  byte[] nodeIdBytes = Bytes.toBytes("nodeId");
    final public  byte[] occurredBytes = Bytes.toBytes("occurred");
    final public  byte[] processIdBytes = Bytes.toBytes("processId");
    final public  byte[] processNameBytes = Bytes.toBytes("processName");
    final public  byte[] stepNameBytes = Bytes.toBytes("stepName");
    final public  byte[] localFileNameBytes = Bytes.toBytes("localFileName");
    final public  byte[] localPathBytes = Bytes.toBytes("localPath");
    final public  byte[] remoteFileNameBytes = Bytes.toBytes("remoteFileName");
    final public  byte[] sentFromBytes = Bytes.toBytes("sentFrom");
    final public  byte[] sentToBytes = Bytes.toBytes("sentTo");
    final public  byte[] clientNameBytes = Bytes.toBytes("clientName");
    final public  byte[] clientIdBytes = Bytes.toBytes("clientId");
    final public  byte[] corelationId = Bytes.toBytes("co_relation_id");
    final public  byte[] sub_co_relation_id = Bytes.toBytes("sub_co_relation_id");
    
    final public  byte[] timeStampBytes = Bytes.toBytes("timestamp");
    final public  byte[] duration = Bytes.toBytes("duration");
    final public  byte[] successValue = Bytes.toBytes("successValue");
    final public  byte[] successPerValueBytes = Bytes.toBytes("successPerValue");
}
