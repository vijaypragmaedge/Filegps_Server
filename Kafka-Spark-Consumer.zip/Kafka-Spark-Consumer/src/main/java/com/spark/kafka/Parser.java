package com.spark.kafka;

import org.apache.avro.Schema;
import org.apache.avro.file.DataFileWriter;
import org.apache.avro.generic.GenericDatumReader;
import org.apache.avro.generic.GenericDatumWriter;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.io.*;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.InputStream;

/**
 * Created by karamjit on 4/12/17.
 */
public class Parser {
    String schemastr = "{\"namespace\": \"com.upwork.kafka\",\n" +
            " \"type\": \"record\",\n" +
            " \"name\": \"Trans\",\n" +
            " \"fields\": [\n" +
            "   {\"name\": \"AcctNbr\", \"type\": \"string\"},\n" +
            "   {\"name\": \"TransID\", \"type\": \"string\"},\n" +
            "   {\"name\": \"CurrencyCd\",  \"type\": \"int\"},\n" +
            "   {\"name\": \"TransAmt\",  \"type\": \"int\"},\n" +
            "   {\"name\": \"TransStatus\",  \"type\": \"string\"},\n" +
            "   {\"name\": \"TranspostDt\",  \"type\": \"long\"},\n" +
            "   {\"name\": \"LoadTime\",  \"type\": \"long\"},\n" +
            "   {\"name\": \"SrcTxtName\", \"type\": \"string\"},\n" +
            "   {\"name\": \"TransType\", \"type\": \"string\"},\n" +
            "   {\"name\": \"BatchId\", \"type\": \"long\"},\n" +
            "   {\"name\": \"EffectiveDt\", \"type\": \"long\"},\n" +
            "   {\"name\": \"ExpiredDt\", \"type\": \"long\"},\n" +
            "   {\"name\": \"SrceSystemId\", \"type\": \"int\"}\n" +
            " ]\n" +
            "}";

    public Trans parseNew(String row) {

       // DatumReader<TestTrans> userDatumReader = new SpecificDatumReader<TestTrans>(TestTrans.class);
      //  DataFileReader<TestTrans> dataFileReader = new DataFileReader<TestTrans>(file, userDatumReader);
        long t = System.currentTimeMillis();
        Trans test = new Trans();

        InputStream input = new ByteArrayInputStream(row.getBytes());
        DataInputStream din = new DataInputStream(input);

        try {


            Schema schema = Schema.parse(schemastr);

            Decoder decoder = DecoderFactory.get().jsonDecoder(schema, din);

            DatumReader<Trans> reader = new GenericDatumReader<Trans>(schema);
            GenericRecord result  = reader.read(test, decoder);

            /**
             * All-args constructor.
             * @param AcctNbr The new value for AcctNbr
             * @param TransID The new value for TransID
             * @param CurrencyCd The new value for CurrencyCd
             * @param TransAmt The new value for TransAmt
             * @param TransStatus The new value for TransStatus
             * @param TranspostDt The new value for TranspostDt
             * @param LoadTime The new value for LoadTime
             * @param SrcTxtName The new value for SrcTxtName
             * @param TransType The new value for TransType
             * @param BatchId The new value for BatchId
             * @param EffectiveDt The new value for EffectiveDt
             * @param ExpiredDt The new value for ExpiredDt
             * @param SrceSystemId The new value for SrceSystemId
             */
            test = new Trans();
            test.setAcctNbr(result.get("AcctNbr").toString());
            test.setTransID(result.get("TransID").toString());
            test.setCurrencyCd((Integer) result.get("CurrencyCd"));
            test.setSrcTxtName(result.get("SrcTxtName").toString());
            test.setTransAmt((Integer) result.get("TransAmt"));
            test.setTransStatus(result.get("TransStatus").toString());
            test.setTransType(result.get("TransType").toString());
            test.setTranspostDt((Long) result.get("TranspostDt"));
            test.setLoadTime((Long) result.get("LoadTime"));
            test.setBatchId((Long) result.get("BatchId"));
            test.setEffectiveDt((Long) result.get("EffectiveDt"));
            test.setExpiredDt((Long) result.get("ExpiredDt"));
            test.setSrceSystemId((int) result.get("SrceSystemId"));
            return test;
        }catch(Exception e){
                e.printStackTrace();
        }
        return test ;

    }
    public Trans parse(String row) {
        InputStream input = null;
        DataFileWriter<GenericRecord> writer = null;
        Encoder encoder = null;
        ByteArrayOutputStream output = null;
        try {
            byte[] avroByteArray = fromJasonToAvro(row,schemastr);

            Schema schema = Schema.parse(schemastr);
            DatumReader<GenericRecord> reader1 = new GenericDatumReader<GenericRecord>(schema);

            Decoder decoder1 = DecoderFactory.get().binaryDecoder(avroByteArray, null);
            GenericRecord result = reader1.read(null, decoder1);

            Trans test = new Trans();
            test.setAcctNbr(result.get("AcctNbr").toString());
            test.setTransID(result.get("TransID").toString());
            test.setCurrencyCd((Integer) result.get("CurrencyCd"));
            test.setSrcTxtName(result.get("SrcTxtName").toString());
            test.setTransAmt((Integer) result.get("TransAmt"));
            test.setTransStatus(result.get("TransStatus").toString());
            test.setTransType(result.get("TransType").toString());
            test.setTranspostDt((Long) result.get("TranspostDt"));
            test.setLoadTime((Long) result.get("LoadTime"));
            test.setBatchId((Long) result.get("BatchId"));
            test.setEffectiveDt((Long) result.get("EffectiveDt"));
            test.setExpiredDt((Long) result.get("ExpiredDt"));
            test.setSrceSystemId((int) result.get("SrceSystemId"));
            return test;
        } catch (Exception e) {
            e.printStackTrace();

        } finally {
            try {
                input.close();
            } catch (Exception e) {
            }
        }
        Trans test = new Trans();
        return test;
    }
    /**
     * @param json
     * @param schemastr
     * @throws Exception
     */
    static byte[] fromJasonToAvro(String json, String schemastr) throws Exception {

        InputStream input = new ByteArrayInputStream(json.getBytes());
        DataInputStream din = new DataInputStream(input);

        Schema schema = Schema.parse(schemastr);

        Decoder decoder = DecoderFactory.get().jsonDecoder(schema, din);

        DatumReader<Object> reader = new GenericDatumReader<Object>(schema);
        Object datum = reader.read(null, decoder);


        GenericDatumWriter<Object>  w = new GenericDatumWriter<Object>(schema);
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

        Encoder e = EncoderFactory.get().binaryEncoder(outputStream, null);

        w.write(datum, e);
        e.flush();

        return outputStream.toByteArray();
    }
/*
       // DatumReader<TestTrans> userDatumReader = new SpecificDatumReader<TestTrans>(TestTrans.class);
      //  DataFileReader<TestTrans> dataFileReader = new DataFileReader<TestTrans>(file, userDatumReader);
        long t = System.currentTimeMillis();
        TestTrans test = new TestTrans();
        test.setAcctNbr("XX999999999");
        test.setTransID(UUID.randomUUID().toString());
        test.setCurrencyCd(1);
        test.setLoadTime(t);
        test.setSrcTxtName("ABC");
        test.setTransAmt(200);
        test.setTransStatus("pending");
        test.setTranspostDt(t);
        test.setLoadTime(t);
        InputStream input = new ByteArrayInputStream(row.getBytes());
        DataInputStream din = new DataInputStream(input);
        TestTrans obj = new TestTrans();
        try {


            Schema schema = Schema.parse(schemastr);

            Decoder decoder = DecoderFactory.get().jsonDecoder(schema, din);

        DatumReader<TestTrans> reader = new GenericDatumReader<TestTrans>(schema);
          TestTrans datum = reader.read(null, decoder);
            return datum;
        }catch(Exception e){
                e.printStackTrace();
        }
        return obj ;
    }*/
}
