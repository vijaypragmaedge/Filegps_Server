package com;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.temporal.TemporalField;
import java.time.temporal.WeekFields;
import java.util.*;

/**
 * Created by karamjit on 4/24/17.
 */
public class Common {
    public static SimpleDateFormat formatter = new SimpleDateFormat("EEE, d MMM yyyy");
    public static SimpleDateFormat onlyDate = new SimpleDateFormat("dd/MM/yyyy");

    public static SimpleDateFormat mmdddyyyyWithSlashes = new SimpleDateFormat("dd/MM/yyyy");  //05/26/2017
    public static SimpleDateFormat mmdddyyyyWithSlashesDt = new SimpleDateFormat("MM/dd/yyyy");  //26/05/2017
    public static String months[] = {"January", "February", "March", "April",
            "May", "June", "July", "August", "September",
            "October", "November", "December"};
    public static int compareDate(Date date1, Date date2) {
        Calendar cal1 = Calendar.getInstance();
        cal1.setTime(date1);

        Calendar cal2 = Calendar.getInstance();
        cal2.setTime(date2);

        cal1.set(Calendar.HOUR_OF_DAY, 0);
        cal1.set(Calendar.MINUTE, 0);
        cal1.set(Calendar.SECOND, 0);
        cal1.set(Calendar.MILLISECOND, 0);

        cal2.set(Calendar.HOUR_OF_DAY, 0);
        cal2.set(Calendar.MINUTE, 0);
        cal2.set(Calendar.SECOND, 0);
        cal2.set(Calendar.MILLISECOND, 0);

        return cal1.compareTo(cal2);


    }
    public static Date currentDate(){

       return new Date();
    }
    public static Date parseDate(String date){

        try {
            return mmdddyyyyWithSlashes.parse(date);
        } catch (ParseException e) {
            return null;
        }
    }
    public static Date parseDate(long date){

        try {
            return new Date(date);
        } catch (Exception e) {
            return null;
        }
    }
    public static Date parseDate(String date, SimpleDateFormat fmt){

        try {
            return fmt.parse(date);
        } catch (ParseException e) {
            return null;
        }
    }
    public static String formatDate(long date, SimpleDateFormat fmt){
        return fmt.format(new Date(date));
    }

    public static String getOnlyDate(){
        return onlyDate.format(new Date());
    }

    public static long getBackDate(int backDay){

        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, -backDay);
        return calendar.getTime().getTime();
    }
    public static long getDateWithoutTime(){
        Calendar c = GregorianCalendar.getInstance();
        c.setTime(new Date());
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTime().getTime();
    }
    public static long getWeekStartDate(Date dt){
        Calendar c = GregorianCalendar.getInstance();
        c.setTime(dt);
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);

        c.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
        return c.getTime().getTime();
    }
    public static long getWeekEndDate(Date dt){

        Calendar c = GregorianCalendar.getInstance();
        c.setTime(dt);
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        c.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
        c.add(Calendar.DATE, 6);
        return c.getTime().getTime();
    }
    public static long getFutureDateByAddingMonths(int Months){

        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH, Months);
        return calendar.getTime().getTime();
    }
    public static Date getFutureDate(int key, int value){
        Calendar calendar = Calendar.getInstance();
        calendar.add(key, value);
        return calendar.getTime();
    }
    public static long randomNumber(int len){
        String numbers = "0123456789";
        Random random = new Random();
        char[] code = new char[len];
        for (int i = 0; i < len; i++) {
            code[i] = numbers.charAt(random.nextInt(numbers.length()));
        }
        return Long.valueOf(String.valueOf(code));
    }
    public static String generateCode(int len){
        String numbers = "abf0123456789gzk";
        Random random = new Random();
        char[] code = new char[len];
        for (int i = 0; i < len; i++) {
            code[i] = numbers.charAt(random.nextInt(numbers.length()));
        }
        return new String(code);
    }
    public static String generatePassword(int len){
        String numbers = "@#abf0123456789gzk$";
        Random random = new Random();
        char[] code = new char[len];
        for (int i = 0; i < len; i++) {
            code[i] = numbers.charAt(random.nextInt(numbers.length()));
        }
        return new String(code);
    }
    public static long getTime(){

        Calendar calendar = Calendar.getInstance();

        return calendar.getTime().getTime();
    }
    public static int getCurrentWeek(){
        LocalDate date = LocalDate.now();
        TemporalField woy = WeekFields.of(Locale.getDefault()).weekOfMonth();
        int weekNumber = date.get(woy);
       // java.util.Calendar calendar = java.util.Calendar.getInstance();
       // return calendar.get(Calendar.WEEK_OF_MONTH);
      //  LocalDate date = LocalDate.now();
       // return date.getDayOfWeek().toString()
        return weekNumber;
    }
    public static String getDayOfWeek(){
      //  Calendar calendar = Calendar.getInstance();
        // return calendar.get(Calendar.WEEK_OF_MONTH);
        LocalDate date = LocalDate.now();
        return date.getDayOfWeek().toString();
    }

    public static int getCurrentDay() {
        LocalDate date = LocalDate.now();
        return date.getDayOfMonth();
    }
    public static int getCurrentMonth(){
        LocalDate date = LocalDate.now();

       return date.getMonth().getValue();
    }
    public static String getCurrentMonthName(){
        LocalDate date = LocalDate.now();

        return date.getMonth().toString();
    }
    public static int getCurrentYear(){
        LocalDate date = LocalDate.now();

        return date.getYear();
    }

    public static String getMonthName(int m) {
        return months[m];
    }





}
